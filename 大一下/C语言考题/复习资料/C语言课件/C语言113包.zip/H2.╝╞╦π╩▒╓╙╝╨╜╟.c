#include <stdio.h>
int main()
{
    int h,m;
	double H,M,E;
    scanf("%d %d",&h,&m);
    M = 1.0*m/60*360;
    H = h%12*30 + M/360*30;
    if (M-H>0)
		E=M-H;
	else E=H-M;
    if(E > 180)
	    E = 360 - E;
    if(m >= 10)
        printf("At %d:%d the angle is %.1f degrees.\n",h,m,E);
    else
        printf("At %d:0%d the angle is %.1f degrees.\n",h,m,E);
    return 0;
}
