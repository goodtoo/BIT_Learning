#include <stdio.h> 

char pf(char x,int n)
{
	int i;
	for(i=1;i<=n;i++)
	{
		x+=1;
		if(x=='Z'+1)
			x='A';
	}
	return x;
}

int main()
{
	int n,i,j;
	char x;
	
	scanf("%d %c",&n,&x);
	if(x<'A'||(x>'Z'&&x<'a')||x>'z')
		{
			printf("Input error!\n");
			return 0;
		}
	if(x>='a')
		x=x-'a'+'A';
	x--;
	if(x=='A'-1)
		x='Z';
	
	for(i=1;i<=n;i++)
	{
		if(i==1)
		{
			for(j=1;j<n;j++)
				printf("%c ",pf(x,j));
			printf("%c\n",pf(x,n));
		}
		else if (i==n)
		{
			for(j=1;j<n;j++)
				printf("%c ",pf(x,n-1+j));
			printf("%c\n",pf(x,n-1+n));
		}
		else
		{
			printf("%c ",pf(x,i));
			for(j=2;j<=n-1;j++)
				printf("  ");
			printf("%c\n",pf(x,n-1+i));
		}
	}
}
