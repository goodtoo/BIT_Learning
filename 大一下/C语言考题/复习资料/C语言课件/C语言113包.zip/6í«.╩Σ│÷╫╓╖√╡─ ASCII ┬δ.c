#include <stdio.h>
int main()
{char x;
scanf("%c",&x);
printf("The ASCII of character '%c' is %d.\n",x,x);
return 0;
}
