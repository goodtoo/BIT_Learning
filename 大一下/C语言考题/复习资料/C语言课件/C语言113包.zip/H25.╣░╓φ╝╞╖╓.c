#include<stdio.h> 
#include<string.h> 

int H1(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H1")==0)
			return 1;
	return 0;
}

int H2(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H2")==0)
			return 1;
	return 0;
}

int H3(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H3")==0)
			return 1;
	return 0;
}

int H4(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H4")==0)
			return 1;
	return 0;
}

int H5(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H5")==0)
			return 1;
	return 0;
}

int H6(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H6")==0)
			return 1;
	return 0;
}

int H7(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H7")==0)
			return 1;
	return 0;
}

int H8(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H8")==0)
			return 1;
	return 0;
}

int H9(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H9")==0)
			return 1;
	return 0;
}

int H10(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H10")==0)
			return 1;
	return 0;
}

int H11(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H11")==0)
			return 1;
	return 0;
}

int H12(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H12")==0)
			return 1;
	return 0;
}

int H13(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"H13")==0)
			return 1;
	return 0;
}

int S12(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"S12")==0)
			return 1;
	return 0;
}

int D11(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"D11")==0)
			return 1;
	return 0;
}

int C10(char s[][4],int n)
{
	int i;
	for(i=0;i<n;i++)
		if(strcmp(s[i],"C10")==0)
			return 1;
	return 0;
}

int end(char s[][4],int n)
{
	int score=0;
	
	if(H1(s,n)==1&&H2(s,n)==1&&H3(s,n)==1&&H4(s,n)==1&&H5(s,n)==1&&H6(s,n)==1&&H7(s,n)==1&&H8(s,n)==1&&H9(s,n)==1&&H10(s,n)==1&&H11(s,n)==1&&H12(s,n)==1&&H13(s,n)==1)
	{
		score+=200;
		if(S12(s,n)==1&&D11(s,n)==1)
			score+=300;
		else if(D11(s,n)==1)
				score+=100;
			else if(S12(s,n)==1)
					score-=100;
		if(C10(s,n)==1)
			score*=2;
	}
	else if(H1(s,n)==0&&H2(s,n)==0&&H3(s,n)==0&&H4(s,n)==0&&H5(s,n)==0&&H6(s,n)==0&&H7(s,n)==0&&H8(s,n)==0&&H9(s,n)==0&&H10(s,n)==0&&H11(s,n)==0&&H12(s,n)==0&&H13(s,n)==0&&S12(s,n)==0&&D11(s,n)==0&&C10(s,n)==1)
		score+=50;
	else
	{
		if(D11(s,n)==1) score+=100;
		if(S12(s,n)==1) score-=100;
		if(H1(s,n)==1) score-=50;
		if(H2(s,n)==1) score-=2;
		if(H3(s,n)==1) score-=3;
		if(H4(s,n)==1) score-=4;
		if(H5(s,n)==1) score-=5;
		if(H6(s,n)==1) score-=6;
		if(H7(s,n)==1) score-=7;
		if(H8(s,n)==1) score-=8;
		if(H9(s,n)==1) score-=9;
		if(H10(s,n)==1) score-=10;
		if(H11(s,n)==1) score-=20;
		if(H12(s,n)==1) score-=30;
		if(H13(s,n)==1) score-=40;
		if(C10(s,n)==1) score*=2;
	}
	
	return score;
}

int main()
{
	char s1[16][4],s2[16][4],s3[16][4],s4[16][4];
	int n1,n2,n3,n4;
	int end1,end2,end3,end4;
	int i;
	
	while(1)
	{
		scanf("%d",&n1);
		getchar();
		for(i=0;i<n1;i++)
		{
			scanf("%s",&s1[i]);
			getchar();
		}
		
		scanf("%d",&n2);
		getchar();
		for(i=0;i<n2;i++)
		{
			scanf("%s",&s2[i]);
			getchar();
		}
		
		scanf("%d",&n3);
		getchar();
		for(i=0;i<n3;i++)
		{
			scanf("%s",&s3[i]);
			getchar();
		}
		
		scanf("%d",&n4);
		getchar();
		for(i=0;i<n4;i++)
		{
			scanf("%s",&s4[i]);
			getchar();
		}
		
		if(n1==0&&n2==0&&n3==0&&n4==0)
			break;
		
		end1=end(s1,n1);
		end2=end(s2,n2);
		end3=end(s3,n3);
		end4=end(s4,n4);
		if(end1>0)
			printf("+");
		printf("%d ",end1);
		if(end2>0)
			printf("+");
		printf("%d ",end2);
		if(end3>0)
			printf("+");
		printf("%d ",end3);
		if(end4>0)
			printf("+");
		printf("%d\n",end4);
	}
	return 0; 
} 
