#include <stdio.h>
int main() 
{
	int wowo,hehe,y,i;
	char a[100];
	scanf("%d",&wowo);
	for(hehe=0;hehe<wowo;hehe++)
	{
		gets(a); 
		if(hehe==0)
		{
			gets(a);
		}
		y=jiancha(a);
		switch(y)
		{
			case 1: printf("Not Safe\n");break;
			case 2: printf("Medium Safe\n"); break;
			case 3: printf("Safe\n");break;
		}
	    for(i=0;i<100;i++)
    	{
	        a[i]=0;
	    }	
	}
	return 0;
}
int jiancha(char a[100])
{
	int b,c,d,i,mark1=0,mark2=0,mark3=0,mark4=0,mark=0,p;
	for(i=0;a[i]!='\0';i++);//ȷ���ַ�������//
	if(i<6)
	{
		return 1;
	} 
	p=i;
	for(i=0;i<p;i++)
	{
		if(a[i]>=48&&a[i]<=57&&mark1==0)
		{
			mark1=1;
			mark++;
		}
		else
		{
			if(a[i]>=65&&a[i]<=90&&mark2==0)
			{
				mark2=1;
				mark++;
			}
			else
			{
				if(a[i]>=97&&a[i]<=122&&mark3==0)
				{
					mark3=1;
					mark++;
				}
				else
				{
					if((a[i]<=47||(a[i]>=58&&a[i]<=64)||(a[i]>=91&&a[i]<=96)||a[i]>=123||a[i]==' ')&&mark4==0)
					{
						mark4=1;
						mark++;
					}
				}
			}
		}
	}   
     switch (mark)
    {
    	case 1: return 1;
    	case 2: return 2;
    	case 3: return 3;
		case 4: return 3; 
	}	
}
