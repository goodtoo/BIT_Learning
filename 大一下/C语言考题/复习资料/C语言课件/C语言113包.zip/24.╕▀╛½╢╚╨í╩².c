#include <stdio.h> 
int main()
{
    int a,b,m,n,i;
    scanf("%d/%d",&a,&b);
    m=a;
    printf("0.");
    for(i=1;i<=200;++i)
    {  
    	m=m*10;
    	n=m/b;
    	m=m-n*b;
    	printf("%d",n); 
		if(m==0)
			i=201;
	}
	printf("\n");
	return 0;
}
