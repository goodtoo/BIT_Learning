#include <stdio.h>

char a[100];

int crazy(int y,int m,int d) 
{
	int y0=2012,m0=4,d0=9,n=0,k,chu,yu;
 	while(y != y0 || m != m0 || d != d0)
	{
		k = y0 % 4 == 0 && y0 % 100 != 0 || y0 % 400 == 0;
  		d0++;
		if  (((m0==1||m0==3||m0==5||m0==7||m0==8||m0==10||m0==12)&&d0==32)||((m0==4||m0==6||m0==9||m0==11)&&d0==31)||((k==0&&m0==2&&d0==29)||(k==1&&m0==2&&d0==30)))
  		{
   			m0++;
   			d0 = 1;
  		}
  		if(m0 == 13)
		{
			y0++;
 			m0 = 1;
		}
		n++;
 	}
	return n;
}

void pf(int time,int week)
{
	int a[5][5]={3,4,5,1,2,2,3,4,5,1,1,2,3,4,5,5,1,2,3,4,4,5,1,2,3},temp,flag=0;
	temp=a[time][week];
	switch(temp)
	{
		case 1:printf("1 and 6.\n");break;
		case 2:printf("2 and 7.\n");break;
		case 3:printf("3 and 8.\n");break;
		case 4:printf("4 and 9.\n");break;
		case 5:printf("5 and 0.\n");break;
	}
}

int main()  
{  
	int y,m,d,day,time,week,flag=0;
	
	scanf("%d %d %d",&y,&m,&d);

	day=crazy(y,m,d);
	time=(day/91)%5;
	switch((day+1)%7)
	{
		case 1:week=0;break;
		case 2:week=1;break;
		case 3:week=2;break;
		case 4:week=3;break;
		case 5:week=4;break;
		default :flag=1;
	}
	if(flag==1)
		{
			printf("Free.\n");
			return 0;
		}
	pf(time,week);
    return 0;  
}
	

