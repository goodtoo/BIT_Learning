#include <stdio.h>  
int main()  
{  int n,s, findf( int );  
   scanf("%d", &n);  
   s = findf(n);  
   printf("%d\n", s);  
   return 0;  
}  
int findf(int x)  
{  
    if(x>=0&&x<=4)  
        return 1;  
    if(x>4&&x%2==0)  
        return findf(x-1)+findf(x-3);  
    if(x>4&&x%2!=0)  
        return findf(x-2)+findf(x-4);  
    return -1;  
}  
