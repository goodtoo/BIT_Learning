#include <stdio.h>
int main()
{
	int x,a,k = 0,b,yu;
	scanf("%d",&x);
	if(x < 0)
	{
		printf("fu ");
		x=-x;
	}
	for(a=0;;a++)
	{
		k=10*k+x%10;
		x/=10;
		if (x==0)
		break;
	}
	x=k;
	for(b = 0;b <= a;b++)
	{
		yu=x % 10;
		switch (yu)
		{ 
	 		case 0:printf("ling");break;
			case 1:printf("yi");break;
			case 2:printf("er");break;
			case 3:printf("san");break;
			case 4:printf("si");break;
			case 5:printf("wu");break;
			case 6:printf("liu");break;
			case 7:printf("qi");break;
			case 8:printf("ba");break;
			default:printf("jiu");break;
		}	
		x=x / 10;
		if(b < a) 
			printf(" ");
		if(b == a) 
			printf("\n");
	}
	return 0;
}
