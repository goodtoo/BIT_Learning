#include <stdio.h>  
int main()  
{ 
	char temp,str[1000];
	int fu=0,i=0,j=0,point=0,wei,n,len,flag=0; 
   
	for(j=0;j<1000;j++)
		str[j]='0';
	while(scanf("%c",&temp)!=EOF&&temp!='e'&&temp!='E')
		if(temp>='0'&&temp<='9')
			str[i++]=temp;
			else if(temp=='.')
					point=i;
				else if(temp=='-')
						fu=1;
	if(point==0)
		point=i;
	len=i;
	scanf("%d",&n);
	
	if(str[0]=='0')
	{
		for(i=0;i<len;i++)
			str[i]=str[i+1];
		len-=1;
		point-=1;
	} 
	wei=n-len+point;

	if(fu==1)
		printf("-");      
	
	if(wei>=0) 
	{
		for(j=0;j<len;j++)
			printf("%c",str[j]);
		for(j=0;j<wei;j++)
			printf("0");
		printf(".");
		for(i=0;i<=7;i++)
			printf("0");
		printf("\n");
	}
	else if(len+wei>0)
		{
			for(j=0;j<len;j++)
			{
				if(str[j]!='0'||j==len+wei-1) 
					printf("%c",str[j]);
				if(j==len+wei-1)
					{
						printf(".");
						break;
					}	
			}
			for(i=j+1;i<=j+8;i++)
				printf("%c",str[i]);
			printf("\n");
		}
		else
		{
			printf("0.");
			for(j=0;j<-wei-len;j++)
				{
					printf("0");
					flag+=1;
					if(flag==8)
						break;
				}
			for(j=0;j<len;j++)
				{
					if(flag==8)
						break;
					printf("%c",str[j]);
					flag+=1;
				}
			for(;flag<8;flag++)
				printf("0");	
			printf("\n");	
		}
        
		return 0;    
}
