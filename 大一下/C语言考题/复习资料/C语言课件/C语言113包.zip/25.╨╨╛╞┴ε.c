#include <stdio.h>
int main()
{ 	
	long a,b,flag,k,a0,p,q=0;
	scanf("%ld %ld",&a,&b);
	for(a;a<=b;a++)
	{
		flag=0;
		if (a<0)
			a0=-a;
		else
			a0=a;
		for(k=10;k>=0;k--)
		{
			p=a0%10;
			a0/=10;
			if (p==7)
				flag=1;
		}
		if (a%7==0)
			flag=1;
		if (flag==1)
			q+=1;
	}
	printf("%ld\n",q);
	return 0;
}
