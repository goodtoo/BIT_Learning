#include<stdio.h> 
int main() 
{ 
    double x,y,z,a=1,b=1,c=1,d=1,a1,b1,c1,d1;
	scanf("%lf %lf %lf",&x,&y,&z);
	for(a1=1;a1<=x;a1++)
		{
			a = a*a1;
		} 
	for(b1 = 1;b1 <= y;b1++)
		{
			b = b*b1;
		}
	for(c1 = 1;c1 <= z;c1++)
		{
			c = c*c1;
		}
	for(d1 = 1;d1 <= x+y+z;d1++)
		{
			d = d*d1;
		}
    printf("%.0f\n",d/a/b/c);
    return 0;
}
