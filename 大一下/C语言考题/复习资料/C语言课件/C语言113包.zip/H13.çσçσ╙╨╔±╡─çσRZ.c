#include <stdio.h>  
int main()   
{  
    int n,max=8,hang,lie,mid,i,j,k,i2,m1=2;
    char a[514][514];
	scanf("%d",&n);
	for (i=1;i<n;i++)
	{
		max*=2;
	}
	int lie1=1,lie2=max,hang1=1,liemid1,liemid2,hang2,hang3;
	for (i=1;i<=max;i++)
	for (j=1;j<=max;j++)
	{
		a[i][j]=' ';
	}
	k=n+1;
	hang2=hang1+2;
	hang3=max/2-1;
	for (i2=1;i2<=n+1;i2++)
	{
	liemid1=max/2-1;
	liemid2=max/2+2;
	for (i=1;i<=max;i++)
	for (j=1;j<=max;j++)
	{
		if ((i==hang1||i==max)&&(j==lie1||j==lie2))
			a[i][j]='+';
		else if((j==lie1||j==lie2)&&(i>hang1))
				a[i][j]='|';
			else if(i==hang1&&j>=lie1&&j<=lie2)
					a[i][j]='-';
				else if(i==max&&a[i][j]!='+')
						a[i][j]='-';
					else if(i2<n+1&&i<=hang3&&i>=hang2&&j==liemid1)
						{
							a[i][j]='/';
							liemid1=liemid1-1;
							if (i>hang3)
								liemid1=0;
						}
						else if(i2<n+1&&i<=hang3&&i==hang2&&j==liemid2)
						{
							a[i][j]=92;
							liemid2=liemid2+1;
							if (i>hang3)
								liemid2=max+1;
							hang2+=1;
						}		
	}
	hang1=hang1+max/m1;
	hang2=hang1+2;
	hang3=hang1+max/m1/2-2;
	lie1=lie1+max/m1/2;
	lie2=lie2-max/m1/2;
	m1*=2;
	}
	
	for (i=1;i<=max;i++)
	for (j=1;j<=max;j++)
	{
		printf("%c",a[i][j]);
		if (j==max)
			printf("\n");
	}
	return 0;  
}  
