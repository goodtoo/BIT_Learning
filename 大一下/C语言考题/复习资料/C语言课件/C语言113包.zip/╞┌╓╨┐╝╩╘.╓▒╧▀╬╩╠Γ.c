#include <stdio.h>

int main()
{
	long x1,x2,y1,y2;
	long n,x0,y0,temp;
	int i,flag=0;
	
	scanf("%ld,%ld",&x1,&y1);
	getchar();
	scanf("%ld,%ld",&x2,&y2);
	getchar();
	scanf("%ld",&n);
	getchar();
	
	for(i=1;i<=n;i++)
	{
		scanf("%ld,%ld",&x0,&y0);
		getchar();
		temp=(x0-x1)*(y0-y2)-(y0-y1)*(x0-x2);
		if(temp==0)
		{
			printf("%ld,%ld\n",x0,y0);
			flag=1;
		}
	}
	
	if(flag==0)
		printf("NoOut.\n");
	
	return 0;
}
