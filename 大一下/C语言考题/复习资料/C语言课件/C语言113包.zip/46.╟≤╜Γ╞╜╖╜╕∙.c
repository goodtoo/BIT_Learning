#include <stdio.h>  
#include <math.h>
double gen(double x,double p,double e)  
{  
    double y;  
      
    if((p*p-x>0?p*p-x:x-p*p)<e)   
        y=p;  
    else  
        y=gen(x,(p+x/p)/2,e);  
    return y;  
}  
  
int main()  
{  
    double x,p,e,y;  
      
    scanf("%lf",&x);  
    scanf("%lf",&e);  
    
    p=sqrt(x);
        
    printf("%.8lf\n",gen(x,p,e));  
    return 0;  
}
