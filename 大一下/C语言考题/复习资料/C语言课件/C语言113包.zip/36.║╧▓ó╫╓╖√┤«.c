#include <stdio.h>  
#include <string.h>  
int main()  
{  
    char a[100],b[100],temp;  
    int i,j;  
  
    gets(a);  
    gets(b);  
    strcat(a,b);  
    for(i=0;i<strlen(a);i++)  
    {  
        for(j=0;j<i;j++)  
        {  
            if(a[i]<a[j])  
            {  
                temp=a[i];  
                a[i]=a[j];  
                a[j]=temp;  
            }  
        }  
    }  
    puts(a);  
    return 0;  
}  

