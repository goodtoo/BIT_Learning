#include <stdio.h>  
#include <string.h>  
int main()   
{  
    int x[100][100];  
    int n,n0,a,b,a0,b0,a2=1,b2=0;  
    int i,j,k=1;  
      
    scanf("%d",&n);  
    a=0;  
    b=n-1;  
      
    for(i=0;i<n;i++)  
        for(j=0;j<n;j++)  
            x[i][j]=k++;  
              
    for(i=1;i<=n*2-1;i++)  
    {  
        n0=i>n?2*n-i:i;  
        if(i<=n)  
            {  
                a0=a;  
                b0=b;  
                for(j=1;j<=n0;j++)  
                    printf("%3d",x[a++][b++]);  
                printf("\n");  
                a=0;  
                b=b0-1;  
            }  
        else  
            {  
                a0=a2;  
                b0=b2;  
                for(j=1;j<=n0;j++)  
                    printf("%3d",x[a2++][b2++]);  
                printf("\n");  
                a2=a0+1;  
                b2=0;  
            }  
    }  
    return 0;  
}  
