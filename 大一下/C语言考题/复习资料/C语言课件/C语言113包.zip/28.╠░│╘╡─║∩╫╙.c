#include <stdio.h>  
int main()   
{  
    int a[100]={0,1},day,i;  
    scanf("%day",&day);  
    for (i = 2;i <= day;i++)  
    {  
        a[i] = (a[i-1] + day + 1 - i) * 2;  
    }  
    if (day > 1)  
    printf("The monkey got %d peaches in first day.\n",a[day]);  
    else  
    printf("The monkey got 1 peach in first day.\n");  
    return 0;  
}  
