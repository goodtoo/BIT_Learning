#include <stdio.h>
#include <string.h> 

int main()
{
	char a[101],b[11],c[11],d[1001];
	gets(a);
	gets(b);
	gets(c);
	
	swap(&a,&b,&c,&d);
	printf("%s\n",d);
	return 0;
}

int swap(char *a,char *b,char *c,char *d)
{
	int num=0,num2=0;
	for(;*c!='\0';c++)
		num2++;
	c-=num2;
	while(*a!='\0')
	{
		num=0;
		for(num=0;*a==*b&&*b!='\0';a++,b++)
			num++;
		if(*b=='\0')
		{	
			for(;*c!='\0';c++,d++)
				*d=*c;
			b-=num;
			c-=num2;
		}
		else
		{
	        a-=num;
   		    b-=num;
    		*d=*a;
			d++;
			a++;	
		}
	}
	*d='\0';
}
