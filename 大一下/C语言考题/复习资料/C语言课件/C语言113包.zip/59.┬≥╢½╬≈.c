#include <stdio.h>  
  
typedef struct buy  
{  char  gname;  
   int   sname;  
   int   gprice;  
} BUY;  
  
int main( )  
{  int i, j, n;  
   int min, price[10][3];  
   int findm( int n, int price[][3], BUY scheme[] );  
  
   static BUY scheme[3]={ {'A', 0, 0}, {'B', 0, 0}, {'C', 0, 0} };  
  
   scanf( "%d", &n );  
   for( i = 0; i < n; i++ )  
    for( j = 0; j < 3; j++ )  
       scanf( "%d", &price[i][j] );  
  
   min = findm( n, price, scheme );  
  
   printf("Total Money are : %d\nGoods-Name  Shop-Name  Goods-Price\n", min );  
   for ( i=0; i < 3; i++ )  
       printf("         %c:%10d%13d\n", scheme[i].gname, scheme[i].sname, scheme[i].gprice );  
   return 0;  
}  

int findm( int n, int a[ ][3], BUY scheme[ ] )   
{  
    int i,j,k,x,y,z,p=10000;  
    for(i=0;i<n;i++)  
        for(j=0;j<n;j++)  
            for(k=0;k<n;k++)  
                if(a[i][0]+a[j][1]+a[k][2]<p&&i!=j&&i!=k&&j!=k)  
                {  
                    p=a[i][0]+a[j][1]+a[k][2];  
                    x=i+1; y=j+1; z=k+1;  
                }  
                  
    scheme[0].sname=x; scheme[0].gprice=a[x-1][0];  
    scheme[1].sname=y; scheme[1].gprice=a[y-1][1];  
    scheme[2].sname=z; scheme[2].gprice=a[z-1][2];  
    return p;  
}  
