#include <stdio.h>  
int main()  
{  
    int a[100][100],n,i=0,j=0,time0,time,k=1;  
    scanf("%d",&n);  
    if(n%2==1)  
    a[(n-1)/2][(n-1)/2]=n*n;  
    for(time0=n-1;time0>0;time0-=2)  
    {  
        for(time=0;time<time0;time++)  
            a[i][j++]=k++;  
        for(time=0;time<time0;time++)  
            a[i++][j]=k++;  
        for(time=0;time<time0;time++)  
            a[i][j--]=k++;  
        for(time=0;time<time0;time++)  
            a[i--][j]=k++;  
        i++;j++;  
    }  
    for(i=0;i<n;i++)  
    {  
        for(j=0;j<n;j++)  
        printf("%3d",a[i][j]);  
        printf("\n");  
    }  
    return 0;  
}  
