#include <stdio.h>
void swap(int *, int *);  
int input(int *, int );  
int output(int *, int );  
int main()  
{    
    int n, k, a[100], b[100];  
    scanf("%d", &n);  
    input(a, n);  
    input(b, n);  
    for ( k=0; k<n; k++ )  
    {   if( a[k] > b[k] )   
            swap(&a[k], &b[k]);   
    }  
    output(a, n);  
    output(b, n);   
    return 0;  
} 
void swap(int *pa,int *pb)
{
	int temp;
	temp=*pa;
	*pa=*pb;
	*pb=temp;
}
input(int *pa,int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%d",pa);
		pa++;
	}
}
output(int *pa, int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d,",*pa);
		pa++;
	}
	printf("\n");
}
