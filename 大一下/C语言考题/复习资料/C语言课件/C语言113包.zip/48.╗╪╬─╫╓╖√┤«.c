#include <stdio.h>  
#include <string.h>  
  
int huiwen(char a[])  
{  
    int flag=0,end=0,i,len;  
      
    len=strlen(a);  
    if(a[0]==a[len-1])  
        flag=1;  
      
    if(flag==1)  
    {     
        for(i=0;i<len-2;i++)  
            a[i]=a[i+1];  
        a[len-2]='\0';  
        if(len==2||len==1)  
            end=1;  
        else  
            end=huiwen(a);  
    }  
    else  
        end=0;  
    return end;  
}  
  
int main()   
{  
    char a[10000];  
      
    gets(a);  
    if(a[0]==0)  
        {  
            printf("Yes\n");  
            return 0;  
        }  
    if(huiwen(a))  
        printf("Yes\n");  
    else  
        printf("No\n");  
      
    return 0;  
}  

