#include <stdio.h>
int main() 
{
	int i,j,flag=0;
	int a,b,c,n,p,q,end;
	
	scanf("%d,%d,%d",&a,&b,&c);
	n=a+b+c;
	
	for(i=n-1;i>1;i--)
	{
		if(i%2==0)
			continue;
		for(j=3;j<(i+1)/2;j+=2)
			if(i%j==0)
		 		break;
		if(j>=(i+1)/2)
			break;
	}
	p=i;
	for(i=n+1;i<2*n;i++)
	{
		if(i%2==0)
			continue;
		for(j=3;j<(i+1)/2;j+=2)
			if(i%j==0)
		    	break;
    		if(j>=(i+1)/2)
    			break;
	}
	q=i;
	end=10000*p+q;
	printf("%d\n",end);
	return 0;
}
