#include <stdio.h>  
int main()  
{  
    int n,a[100],i,j,mi,min,t;  
    scanf("%d",&n);  
    for(i=1;i<=n;i++)  
        scanf("%d",&a[i]);  
    for(i=1;i<=n;i++)  
    {     
        min=a[i];  
        mi=i;  
        for(j=i;j<=n;j++)  
        {  
            if(min>a[j])  
            {  
                min=a[j];  
                mi=j;  
            }  
        }  
        t=a[i];  
        a[i]=a[mi];  
        a[mi]=t;  
    }  
    for(i=1;i<=n;i++)  
        {  
            printf("%d",a[i]);  
            if(i!=n)  
                printf(" ");  
        }  
    printf("\n");  
    return 0;  
}  

