#include <stdio.h>  
void sort(int *, int, int (*)(int, int));  
int input(int *, int );  
int output(int *, int );  
int up(int, int);       
int down(int, int);        
  
int main()  
{  
    int n, flag, a[100];  
    scanf("%d%d", &n, &flag);   
    input(a, n);  
    if ( flag==0 )  
        sort(a, n, up);     
    else   
        sort(a, n, down);  
    output(a, n);  
    return 0;  
}  

int input(int *a,int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%d",a);
		a++;
	}
}

int output(int *a, int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d,",*a);
		a++;
	}
	printf("\n");
}
void sort(int *a,int n,int (*pf)(int x, int y))
{
	int i,p,temp,j;
	if(pf==up)
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(*(a+i)>*(a+j))
				{
					temp=*(a+i);
					*(a+i)=*(a+j);
					*(a+j)=temp;
				}
			}
		}
	else
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(*(a+i)<*(a+j))
				{
					temp=*(a+i);
					*(a+i)=*(a+j);
					*(a+j)=temp;
				}
			}
		}
}
up(int a, int b)
{
}
down(int a,int b)
{
}
