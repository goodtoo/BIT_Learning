#include <stdio.h>
#include <string.h>

int main() 
{
	char a[100],b[100];
	int i,j,len,x,y;
	
	gets(a);
	len=strlen(a);
	
	for(i=0,j=0;i<len;i++)
	{
		if(a[i]!='-')
		{
			b[j]=a[i];
			j++;
        }
		
		else if(((a[i-1]>='0'&&a[i-1]<='9'&&a[i+1]>='0'&&a[i+1]<='9')||(a[i-1]>='A'&&a[i-1]<='Z'&&a[i+1]>='A'&&a[i+1]<='Z')||(a[i-1]>='a'&&a[i-1]<='z'&&a[i+1]>='a'&&a[i+1]<='z'))&&a[i+1]-a[i-1]>1)
		{
			x=a[i-1];
			y=a[i+1];
			for(x++;x<y;x++)
			{
				b[j]=x;
				j++;
			}
		}
			else
			{
				b[j]=a[i];
				j++;
			}
	}
	b[j]='\0';
	puts(b);
	return 0;
}
