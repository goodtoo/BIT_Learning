#include <stdio.h>
int main() 
{
	char x;
	double a,b;
	scanf("%c %lf",&x,&a);
	if (x=='F')
		{b=(a*9/5)+32;
		printf("The Fahrenheit is %.2f\n",b);}
	else{b=(a-32)*5/9;
		printf("The Centigrade is %.2f\n",b);}
	return 0;
}
