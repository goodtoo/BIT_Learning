#include <stdio.h>
int main ()
{
 int y,m,d,c,run;
 scanf("%d",&y);scanf("%d",&m);scanf("%d",&d);scanf("%d",&c);
 c--;
 for(c;c>=0;c--)
 {
  if((y%4==0&&y%100!=0)||(y%400==0))
  run = 1 ;
   else run = 0 ;
  d++;
  if  (((m==1||m==3||m==5||m==7||m==8||m==10||m==12)&&d==32)||((m==4||m==6||m==9||m==11)&&d==31)||((run==0&&m==2&&d==29)||(run==1&&m==2&&d==30)))
  {
   m++;
   d=1;
  }
  if(m==13)
  {
   y++;
   m=1;
  }
 }
 printf("%d.%d.%d\n",y,m,d);
 return 0;
}
