#include <stdio.h>  
struct nn  
{  int no;     
   int num;     
};  
  
typedef struct nn DATA;  
  
int number( char * , DATA []);  
  
int main( )  
{     
   DATA b[100];    
   char sa[500];    
   int i, n;    
   gets( sa );   
   n = number( sa, b );   
   for ( i=0; i<n; i++ )   
       printf("%d %d\n", b[i].num, b[i].no );   
   return 0;  
}  

int number(char * str,DATA a[])   
{  
    int n=0,x,y=0;  
    for(x=0;1;x++)   
    {  
        a[x].num=atoi(str);  
        for(;*str<='9'&&*str>='0';str++);  
        n++;  
        a[x].no=1;  
        if(*(str)==0)  
            break;  
        str++;  
    }   
    for(x=0;x<n;x++)  
    for(y=0;y<n;y++)   
    {  
        if(a[x].num>a[y].num)   
        a[x].no++;   
        else if(a[x].num==a[y].num&&(x>y))   
        a[x].no++;  
    }  
    return n;  
}  

