#include <stdio.h>    
int panduan(char a,char b,char c,char d,char e,char f,char g,char h) 
{ 
    int flag=0,i;
	char x[9]={a,b,c,d,e,f,g,h};
	
	for(i=0;i<=8;i++)
		if(x[i]=='*')
			flag+=1;
	return flag;
}

int main()  
{  
    int n,m,i,j,k=1,flag=0;   
	char a[103][103],ch;
    
	while(scanf("%d %d",&n,&m)!=EOF)  
    {
    	if(n==0)
    		return 0;
    	for(i=0;i<=102;i++)
    		for(j=0;j<=102;j++)
    			a[i][j]='.';
    	if(flag==1)
    		printf("\n");
		for(i=1;i<=n;i++)
    		for(j=1;j<=m;j++)
    			{
					if(j==1) 
						ch=getchar();
					scanf("%c",&a[i][j]);
				}
		printf("Field #%d:\n",k++);
    	for(i=1;i<=n;i++)
    		for(j=1;j<=m;j++)
    			{
					if(a[i][j]=='*')
						printf("*");
					else
						printf("%d",panduan(a[i-1][j],a[i-1][j-1],a[i][j-1],a[i+1][j-1],a[i+1][j],a[i+1][j+1],a[i][j+1],a[i-1][j+1]));
					if(j==m)
						printf("\n");
				}
		flag=1;
	}
	return 0;
}  


