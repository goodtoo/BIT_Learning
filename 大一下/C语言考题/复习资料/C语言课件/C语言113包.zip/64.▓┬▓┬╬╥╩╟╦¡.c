#include <stdio.h>  
  
int main()  
{  
    FILE *fp;  
    char name[10],ch;  
    int i,hang;  
    scanf("%s %d",name,&hang);  
    fp=fopen(name,"r");  
    if(fp==NULL)  
    {  
        printf("File Name Error.\n");  
        return 0;  
    }  
    for(i=1;i<hang;)  
    {  
        ch=fgetc(fp);  
        if(ch==EOF)  
        {  
            printf("Line No Error.\n");  
            return 0;  
        }  
        if(ch=='\n')  
            i++;  
    }  
    while(1)  
    {  
        ch=fgetc(fp);  
        if(ch==EOF)  
        {  
            printf("Line No Error.\n");  
            return 0;  
        }  
        if(ch!='\n')  
            printf("%c",ch);  
        else  
            break;  
    }  
    printf("\n");  
    return 0;  
}  

