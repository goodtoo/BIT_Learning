#include<stdio.h>
int main()
{
   	int a[30],b[30];
	char m[30],n[30];
	scanf("%s %s",m,n);
	long k3,k4,x,y;
	int i,j,m1 = 0,m2 = 0,x0 = 0,k1,k2,long1,long2;
	for(i = 0;m[i] != '\0';i++)
	{
		if(m[i] >= 'A' && m[i] <= 'Z')
			a[i] = m[i] - 'A' + 10;
		if(m[i] >= '0' && m[i] <= '9')
			a[i] = m[i] - '0';
		m1 = m1 < (a[i] + 1) ? (a[i] + 1) : m1;
		m1 = m1 < 2 ? 2 : m1;
	}
	for(j = 0;n[j] != '\0';j++)
	{
		if(n[j] >= 'A' && n[j] <= 'Z')
			b[j] = n[j] - 'A' + 10;
		if(n[j] >= '0' && n[j] <= '9')
			b[j] = n[j] - '0';
		m2 = m2 < (b[j] + 1) ? (b[j] + 1) : m2;
		m2 = m2 < 2 ? 2 : m2;
	}
	long1 = i;
	long2 = j;
	for(i = m1;i <= 36&&j <= 36;)
		for(j = m2;j <= 36&& i <= 36;)
		{ 
			x = 0;
			y = 0;
			k3 = 1;
			k4 = 1;
			for(k1 = long1 - 1;k1 >= 0;k1--)
			{   
				x += a[k1] * k3;
				k3 *= i;
			}
			for(k2 = long2 - 1;k2 >= 0;k2--)
			{   
				y += b[k2] * k4;
				k4 *= j;
			}
			if(x < y) 
			i++;
			if (x > y) 
			j++;
			if (x == y)
			{
			   printf("%s (base %d) = %s (base %d)\n",m,i,n,j);
			   x0=1;
			   return 0;
		   }
	}
	if(x0==0) 
		printf("%s is not equal to %s in any base 2..36\n",m,n);
	return 0;
}
