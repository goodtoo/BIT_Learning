#include <stdio.h>  
int main()  
{  
    int m,n,k,i,j,p,q,flag1,flag2,flag3=0;  
    scanf("%d %d",&n,&m);  
    int a[100][100];  
    for(i=0;i<=n-1;i++)  
    for(j=0;j<=m-1;j++)  
        scanf("%d",&a[i][j]);  
    for(i=0;i<=n-1;i++)  
    for(j=0;j<=m-1;j++)  
    {     
        flag1=0;  
        flag2=0;  
        for(p=0;p<=n-1;p++)  
        {  
            if(a[p][j]<a[i][j])  
            flag1=1;  
        }  
        for(q=0;q<=m-1;q++)  
        {  
            if(a[i][q]>a[i][j])  
            flag2=1;  
        }  
        if(flag1==0&&flag2==0)  
        {  
            printf("Point:a[%d][%d]==%d\n",i,j,a[i][j]);  
            flag3=1;  
        }  
    }  
    if(flag3==0)  
        printf("No Point\n");  
    return 0;  
}  
