#include <stdio.h>  
int main()  
{  
    long k = 0,x,a;  
    scanf("%ld",&x);  
    while (k < 20&&x != 1)  
    {  
        if (x % 2 ==0)  
            {  
                a = x;  
                x = x / 2;  
                printf("%ld/2=%ld\n",a,x);  
                k = ++k;  
            }  
        else  
            {  
                a = x;  
                x = x * 3 + 1;  
                printf("%ld*3+1=%ld\n",a,x);  
                k = ++k;  
            }         
    }  
    return 0;  
}  
