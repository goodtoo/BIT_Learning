#include<stdio.h>  
#include<string.h>  
char count(int k)  
{  
    int i;  
    char x='9';  
      
    for(i=1;i<k;i++)  
    {  
        x-=1;  
        if(x=='0'-1)  
            x='z';  
        if(x=='a'-1)  
            x='Z';  
    }  
    return x;  
}  
int main()  
{  
    char a[51],b[51];  
    int i,j,len,k=1,q=0;  
      
    gets(a);  
    len=strlen(a);  
    for(i=0;i<62;i++)  
    {  
        for(j=0;j<len;j++)  
        {  
            if(a[j]==count(k))  
            {  
                b[q]=a[j];  
                q+=1;         
            }         
        }  
        k+=1;         
    }  
    b[q]='\0';  
    puts(b);  
    return 0;  
    }  

