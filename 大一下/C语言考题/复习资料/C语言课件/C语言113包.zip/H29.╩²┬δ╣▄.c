#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void turn(int n,int *a,int ge,int *ti)
{
	int i,j,k,sum=0;
	
	for(i=0;i<7;i++)
		*(a+i)=0;
	switch(n)
	{
		case 0:*(a+6-0)=1,*(a+6-2)=1,*(a+6-3)=1,*(a+6-4)=1,*(a+6-5)=1,*(a+6-6)=1;break;
		case 1:*(a+6-6)=1,*(a+6-4)=1;break;
		case 2:*(a+6-0)=1,*(a+6-1)=1,*(a+6-2)=1,*(a+6-4)=1,*(a+6-5)=1;break;
		case 3:*(a+6-0)=1,*(a+6-1)=1,*(a+6-2)=1,*(a+6-4)=1,*(a+6-6)=1;break;
		case 4:*(a+6-1)=1,*(a+6-3)=1,*(a+6-4)=1,*(a+6-6)=1;break;
		case 5:*(a+6-0)=1,*(a+6-1)=1,*(a+6-2)=1,*(a+6-3)=1,*(a+6-6)=1;break;
		case 6:*(a+6-0)=1,*(a+6-1)=1,*(a+6-2)=1,*(a+6-3)=1,*(a+6-5)=1,*(a+6-6)=1;break;
		case 7:*(a+6-2)=1,*(a+6-4)=1,*(a+6-6)=1;break;
		case 8:*(a+6-0)=1,*(a+6-1)=1,*(a+6-2)=1,*(a+6-3)=1,*(a+6-4)=1,*(a+6-5)=1,*(a+6-6)=1;break;
		case 9:*(a+6-0)=1,*(a+6-1)=1,*(a+6-2)=1,*(a+6-3)=1,*(a+6-4)=1,*(a+6-6)=1;break;
	}
	for(i=0;i<7;i++)
		sum+=*(a+6-i)*pow(2,i);
	*(ti+ge)=sum;
}
int main()
{
	int n,a[5],b[7],i;
	while(1)
	{
		scanf("%d",&n);
		if(n==0)
		break;
		for(i=0;i<5;i++)
		{
			turn(n%10,b,i,a);
			n/=10;
		}
		for(i=0;i<4;i++)
		printf("%X ",a[4-i]);
		printf("%X\n",a[0]);
	}
	return 0;
}
