#include <stdio.h>      
    int x[25]={0},y[25]={1},z[25]={0},len=1;  
void xy(void)  
{  
    int i;  
      
    for(i=0;i<=24;i++)  
        z[i]=0;  
    for(i=0;i<=len-1;i++)  
        {  
            z[i]+=x[i]+y[i];  
                if(z[i]>9&&i==len-1)  
                    len+=1;  
                if(z[i]>9)  
                {  
                    z[i]=z[i]-10;  
                    z[i+1]++;     
                }  
        }  
}  
  
void yz(void)  
{  
    int i;  
      
    for(i=0;i<=24;i++)  
        x[i]=0;  
    for(i=0;i<=len-1;i++)  
        {  
            x[i]+=y[i]+z[i];  
                if(x[i]>9&&i==len-1)  
                    len+=1;  
                if(x[i]>9)  
                {  
                    x[i]=x[i]-10;  
                    x[i+1]++;     
                }  
        }  
}  
  
void zx(void)  
{  
    int i;  
      
    for(i=0;i<=24;i++)  
        y[i]=0;  
    for(i=0;i<=len-1;i++)  
        {  
            y[i]+=x[i]+z[i];  
                if(y[i]>9&&i==len-1)  
                    len+=1;  
                if(y[i]>9)  
                {  
                    y[i]=y[i]-10;  
                    y[i+1]++;     
                }  
        }  
}  
  
int main()  
{  
    int a,b,n,i;  
    scanf("%d %d",&a,&b);  
    n=b-a;  
    for(i=1;i<=n;i++)  
    {  
        if(i%3==1)  
            xy();  
        if(i%3==2)  
            yz();  
        if(i%3==0)  
            zx();  
    }  
    if(n%3==1)  
        for(i=len-1;i>=0;i--)  
            printf("%d",z[i]);  
    if(n%3==2)  
        for(i=len-1;i>=0;i--)  
            printf("%d",x[i]);  
    if(n%3==0)  
        for(i=len-1;i>=0;i--)  
            printf("%d",y[i]);  
    printf("\n");  
    return 0;   
}  

