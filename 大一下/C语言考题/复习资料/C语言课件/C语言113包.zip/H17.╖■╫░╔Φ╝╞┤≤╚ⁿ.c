#include <stdio.h>  
int main()     
{    
    char a[100001],b[100001],c[100001];    
    long i,j,k,chang=0,la,la0=0,lb,lb0=0,lc,lc0=0,t,min,mi,n,h,winner;      
    scanf("%ld %s %s %s",&n,&a,&b,&c);    
    for(i=0;a[i]!='\0';i++)    
    {}    
    chang=i;    
    for(i=0;i<chang;i++)    
    {    
        la=1;    
        if (a[i]==1)  
            continue;  
        else   
            for(j=i+1;j<chang;j++)    
                if (a[j]==a[i])    
                    {  
                        la+=1;  
                        a[j]=1;  
                    }           
        la0=la>la0?la:la0;  
    }    
    for(i=0;i<chang;i++)    
    {    
        lb=1;    
        if (b[i]==1)  
            continue;  
        else   
            for(j=i+1;j<chang;j++)    
                if (b[j]==b[i])    
                    {  
                        lb+=1;  
                        b[j]=1;  
                    }           
        lb0=lb>lb0?lb:lb0;    
    }    
    for(i=0;i<chang;i++)    
    {    
        lc=1;    
        if (c[i]==1)  
            continue;  
        else   
            for(j=i+1;j<chang;j++)    
                if (c[j]==c[i])    
                    {  
                        lc+=1;  
                        c[j]=1;  
                    }           
        lc0=lc>lc0?lc:lc0;    
    }    
    long c1[3]={la0,lb0,lc0},d[3]={1,2,3};   
    for(i=0;i<3;i++)      
    {         
        min=c1[i];      
        mi=i;      
        for(j=i;j<3;j++)      
        {      
            if(min>c1[j])      
            {      
                min=c1[j];      
                mi=j;    
            }      
        }      
        t=c1[i];      
        c1[i]=c1[mi];      
        c1[mi]=t;    
        t=d[i];      
        d[i]=d[mi];      
        d[mi]=t;      
    }  
    if(n==1)  
        {  
            if(c1[2]==chang&&c1[1]==c1[2]-1&&c1[1]!=c1[0])  
                winner=d[1];  
            else if(c1[2]==chang&&c1[1]==c1[2]-1&&c1[1]==c1[0])  
                    printf("Excellent\n");  
                else if(c1[2]==chang&&c1[1]==c1[2]&&c1[1]==c1[0]+1)  
                        winner=d[0];  
                    else if(c1[2]==chang&&c1[1]==c1[2]&&c1[1]==c1[0])  
                            printf("Excellent\n");  
                        else if(c1[2]==chang&&c1[1]==c1[2]-2)  
                                printf("Excellent\n");  
                            else winner=d[2];  
        }  
    else if((n>=chang-c1[1])||c1[1]==c1[2])  
            printf("Excellent\n");  
        else winner=d[2];  
          
    if (winner==1)    
            printf("Beibei\n");    
        else if (winner==2)    
            printf("Lili\n");     
            else if (winner==3)    
                printf("Gonggong\n");   
    return 0;  
}  
