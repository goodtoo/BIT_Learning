#include <stdio.h>

int main()
{
	long money,x,y,z;
	int flag=0,k=1;
	
	scanf("%ld",&money);
	for(x=0;5*x<=money;x++)
		for(y=0;5*x+2*y<=money;y++)
		{
			if((money-2*y-5*x)%10!=0)
			{
				continue;
			}
			z=(money-2*y-5*x)/10;
			if(x%4==0&&y%2==0)
			{
				printf("%d:%ld,%ld,%ld\n",k,x,y,z);
				flag=1;
				k++;
			}
		}
	if(flag==0)
		printf("No!\n");
	return 0;
}
