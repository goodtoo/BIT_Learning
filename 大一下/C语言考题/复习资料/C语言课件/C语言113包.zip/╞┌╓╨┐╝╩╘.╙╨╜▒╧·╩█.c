#include <stdio.h>  
int main()  
{  
    int p1,p2,p3,p4,pm,n1,n2,n3,n4,n;  
      
    scanf("%d,%d,%d,%d",&p1,&p2,&p3,&p4);  
    scanf("%d",&pm);  
    for(n1=1;n1<=pm/(p1+p2+p3+p4);n1++)  
        for(n2=n1;n2<=(pm-p1*n1)/(p2+p3+p4);n2++)  
            for(n3=n2;n3<=(pm-p1*n1-p2*n2)/(p3+p4);n3++)  
                for(n4=n3;p1*n1+p2*n2+p3*n3+p4*n4<=pm;n4++)  
                {  
                    if(p1*n1+p2*n2+p3*n3+p4*n4==pm)  
                    printf("%d,%d,%d,%d\n",n1,n2,n3,n4);  
                }  
    return 0;  
 }  

