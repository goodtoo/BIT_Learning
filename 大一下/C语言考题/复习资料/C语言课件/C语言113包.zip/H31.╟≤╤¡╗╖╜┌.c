#include <stdio.h>  
#include <stdlib.h>  
  
typedef struct node  
{   int         data;  
    struct node * next;  
} NODE;  
  
NODE * find( NODE * , int * );  
void outputring( NODE * );  
void change( int , int , NODE * );  
  
void outputring( NODE * pring )  
{   NODE * p;  
    p = pring;  
    if ( p == NULL )  
        printf("NULL");  
    else  
        do  
        {   printf("%d", p->data);  
            p = p->next;  
        } while ( p != pring );  
    printf("\n");  
    return;  
  
}  
  
int main()  
{   int n, m;  
    NODE * head, * pring;  
  
    scanf("%d%d", &n, &m);  
    head = (NODE *)malloc( sizeof(NODE) );  
    head->next = NULL;  
    head->data = -1;  
  
    change( n, m, head );  
    pring = find( head, &n );  
    printf("ring=%d\n", n);  
    outputring( pring );  
  
    return 0;  
}  
int a[100];  
void change( int n, int m, NODE * head )   
{  
    NODE *p=head,*fp,*temp;  
    int i=0,j=0,flag=0;  
    n%=m;  
    a[i]=n;  
    while(++i)  
    {  
        temp=(NODE*)malloc(sizeof(NODE));  
        p->next=temp;  
        temp->data=n*10/m;  
        temp->next=NULL;  
        n=n*10%m;  
        a[i]=n;  
        for(j=0;j<i;j++)  
            if(a[i]==a[j])  
            {  
                flag=1;  
                break;  
            }  
        if(n==0)  
        {  
            temp->data=-10;  
            return;  
        }  
        if(flag==1)  
        {  
            fp=head;  
            for(i=0;i<=j;i++)  
                fp=fp->next;  
            temp->next=fp;  
            fp->data+=10;  
            return;  
        }  
        p=temp;  
    }  
}  
NODE * find( NODE * head, int * n )   
{  
    *n=0;  
    NODE *p=head->next,*fp;  
    while(1)  
    {  
        if(p->data==-10)  
        return NULL;  
          
        if(p->data>=10)  
        {  
            p->data-=10;  
            (*n)++;  
            for(fp=p;fp->next!=p;fp=fp->next)  
            (*n)++;  
            return p;  
        }  
        p=p->next;  
    }  
}  
