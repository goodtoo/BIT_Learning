#include<stdio.h> 
int main() 
{ 
    double fz1,fm1,fz2,fm2,fm,fz,a,yu,fm10,fm20,fz10;
	scanf("%lf %lf %lf %lf",&fz1,&fm1,&fz2,&fm2);
	fm10=fm1;
	fm20=fm2;
	if (fm1<fm2)
    	{
    		a=fm1;
    		fm1=fm2;
    		fm2=a;
		}
    for(yu=1;yu!=0;)
    	{
    		yu=(int)fm1%(int)fm2;
    		fm1=fm2;
    		fm2=yu;
		}
	fm=fm10*fm20/fm1;
	fz=fz1*fm20/fm1+fz2*fm10/fm1;
	fz10=fz;
	fm10=fm;
	if (fz<fm2)
    	{
    		a=fz;
    		fz=fm;
    		fm=a;
		}
    for(yu=1;yu!=0;)
    	{
    		yu=(int)fz%(int)fm;
    		fz=fm;
    		fm=yu;
		}
	fz10=fz10/fz;
	fm10=fm10/fz;
	if(fm10<0)
	{fm10=-fm10;
	fz10=-fz10;
	}
    printf("%.0f/%.0f\n",fz10,fm10);
    return 0;
}
