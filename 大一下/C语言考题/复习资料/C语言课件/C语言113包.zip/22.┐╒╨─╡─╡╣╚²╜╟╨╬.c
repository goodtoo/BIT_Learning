#include <stdio.h>  
int main()  
{     
    int h,i,j,k;  
    scanf("%d",&h);  
    for(i=1;i<=h;i++)  
    {  
        for(j=1;j<i;j++)  
            printf(" ");  
        for(k=j;k<=2*h-i;k++)  
        {  
            if (i==1)  
                printf("*");  
            else if (k==i||k==2*h-i)  
                    printf("*");  
                else   
                    printf(" ");  
        }  
        printf("\n");  
    }  
    return 0;  
}  
