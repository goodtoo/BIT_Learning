#include <stdio.h>  
  
int end(int x,int y)  
{  
    if(x<y)  
        return x+end(x+1,y);  
    else  
        return x;  
}   
  
int main()    
{    
    int a,b;  
      
    scanf("%d %d",&a,&b);  
    printf("The sum from %d to %d is %d.\n",a,b,end(a,b));   
    return 0;  
}  
