#include <stdio.h>  
char x;
int letter(void)           
{  
    x+=1;
	if(x=='C'||x=='H'||x=='E'||x=='N'||x=='T'||x=='R'||x=='Y')           
        x+=1;  
    if(x=='Z'+1)
    	x='A';
    return(x);  
} 
 
int main()   
{  
    int n,n0;
	int i,j;  
    
	scanf("%d %c",&n,&x);  
    x-=1;
	for(i=1;i<=2*n-1;i++)
	{
		n0=i>n?2*n-i:i;
		for(j=1;j<=n0-1;j++)
			printf(" ");
		if(n0==1)
			for(j=1;j<=2*n-1;j++)
				printf("%c",letter());
		else
		{
			printf("%c",letter());
			for(j=1;j<=2*n-2*n0-1;j++)
				printf(" ");
			if(n0!=n)
				printf("%c",letter());
		}
		printf("\n");
	}  
    return 0;
}  
