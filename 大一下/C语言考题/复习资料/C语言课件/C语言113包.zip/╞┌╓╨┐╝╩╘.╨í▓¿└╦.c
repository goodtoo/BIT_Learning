#include <stdio.h>  
int main()  
{  
    char x;  
    int n,i,i0,im,j;  
      
    scanf("%c %d",&x,&n);  
    for(i=1;i<=n*n;i++)  
    {  
        i0=i%(2*n);  
        im=i0>n?(2*n+1-i0):i0;  
        for(j=1;j<im;j++)  
            printf(" ");  
        printf("%c\n",x);  
    }  
    return 0;  
 }  
