#include<stdio.h> 

struct student 
{ 
 	char name[20]; 
 	int score; 
}; 

void GetName(char name[]) 
{ 
 	int i=0; 
 	char ch; 
	
 	while((ch=getchar())!=',') 
 	{ 
 		name[i]=ch; 
 		i++; 
	} 
	name[i]='\0'; 
} 

void GetScore(int * score) 
{ 
 	scanf("%d\n",score); 
} 

void GetScoreLast(int * score) 
{ 
 	scanf("%d",score); 
} 

void sort(struct student stu[],int N) 
{ 
 	struct student * p; 
 	struct student temp; 

 	int i,j; 
 
 	for(i=0;i<N;i++) 

 	{ 
 		for(j=0;j<N-1;j++) 
 		{ 
 			if(stu[j].score<stu[j+1].score) 
 			{ 
 				temp=stu[j]; 
 				stu[j]=stu[j+1]; 
 				stu[j+1]=temp; 
 			} 
 		} 
 	} 
} 

void print(struct student stu[],int N) 
{ 
 	int i; 
 	for(i=0;i<N;i++) 
 		printf("%s,%d\n",stu[i].name,stu[i].score); 
} 

int main() 
{ 
 	struct student stu[100]; 
 	int N,i; 
 
 	scanf("%d\n",&N); 
 	for(i=0;i<N;i++) 
 	{ 
 		GetName(stu[i].name); 
 		if(i<N-1) 
 			GetScore(&stu[i].score); 
 		else 
 			GetScoreLast(&stu[i].score);
 	} 
 	sort(stu,N); 
 	print(stu,N); 
 	return 0;
} 
