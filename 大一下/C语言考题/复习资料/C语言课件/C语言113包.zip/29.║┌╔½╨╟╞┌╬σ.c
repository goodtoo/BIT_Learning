#include <stdio.h>    
int main()    
{    
    int y,m,d,a,b,c,e,flag=0;    
    scanf("%d",&y);    
    for(m=1;m<=12;m++)  
    {  
    d=13;  
    a=0;  
    a=(y-1900)*365+(y-1901)/4+(y-1601)/400-(y-1901)/100;     
    c=(y%4==0&& y%100!=0||y%400==0);    
    if (m==1) b=0;    
        else if (m==2) b=31;    
            else if (m==3) c==1?b=60:(b=59);    
                else if (m==4) c==1?b=91:(b=90);    
                    else if (m==5) c==1?b=121:(b=120);    
                        else if (m==6) c==1?b=152:(b=151);    
                            else if (m==7) c==1?b=182:(b=181);    
                                else if (m==8) c==1?b=213:(b=212);    
                                    else if (m==9) c==1?b=244:(b=243);    
                                        else if (m==10) c==1?b=274:(b=273);    
                                            else if (m==11) c==1?b=305:(b=304);    
                                                else c==1?b=335:(b=334);    
    e=(d+a+b)%7;  
    if(e==5)  
        flag+=1;  
    }  
    if(flag>=2)  
        printf("There are 2 Black Fridays in year %d.\nThey are:\n",y);  
    else if (flag==1)  
        printf("There is 1 Black Friday in year %d.\nIt is:\n",y);  
    for(m=1;m<=12;m++)  
    {  
    d=13;  
    a=0;  
    a=(y-1900)*365+(y-1901)/4+(y-1601)/400-(y-1901)/100;     
    c=(y%4==0&& y%100!=0||y%400==0);    
    if (m==1) b=0;    
        else if (m==2) b=31;    
            else if (m==3) c==1?b=60:(b=59);    
                else if (m==4) c==1?b=91:(b=90);    
                    else if (m==5) c==1?b=121:(b=120);    
                        else if (m==6) c==1?b=152:(b=151);    
                            else if (m==7) c==1?b=182:(b=181);    
                                else if (m==8) c==1?b=213:(b=212);    
                                    else if (m==9) c==1?b=244:(b=243);    
                                        else if (m==10) c==1?b=274:(b=273);    
                                            else if (m==11) c==1?b=305:(b=304);    
                                                else c==1?b=335:(b=334);    
    e=(d+a+b)%7;  
    if(e==5)  
        printf("%d/%d/%d\n",y,m,d);  
    }  
    return 0;    
}  
