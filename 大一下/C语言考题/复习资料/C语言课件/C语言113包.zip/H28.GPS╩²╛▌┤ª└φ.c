#include <stdio.h>  
#include <string.h>  
  
int time[3]={0};   
  
void gps(char str[])  
{  
    int i,sum=str[1]^str[2],num10,num3,num4;  
    char num,num2;  
      
    if(str[0]=='$'&&str[1]=='G'&&str[2]=='P'&&str[3]=='R'&&str[4]=='M'&&str[5]=='C'&&str[6]!='\0')  
    {  
        for(i=3; str[i]!='*'; i++)  
            sum = sum ^ str[i];  
        sum=sum%65536;  
          
        num=str[i+1], num2=str[i+2];  
        if(num >='A' && num<='F')  
            num3 = 10+(num-'A');  
        else  
            num3 = num - '0';  
          
        if(num2 >='A' && num2<='F')  
            num4 = 10+(num2-'A');  
        else  
            num4 = num2 - '0';  
        num10 =num3*16 + num4;  
  
        for(i=7; str[i]!='*'; i++)  
            if(str[i]==',')  
                break;  
                  
        if(str[i+1]=='A'&&num10==sum)  
        {  
            time[0] = (10*(str[7]-'0') + (str[8]-'0')+8)%24;  
            time[1] = 10 * (str[9] - '0') + (str[10] - '0');  
            time[2] = 10 * (str[11] - '0') + (str[12] - '0');   
        }  
    }  
}  
  
int main()   
{  
    char str[5000];  
    do  
    {  
    scanf("%s",str);  
        gps(str);  
    }while(strcmp(str,"END")!=0);  
    printf("%02d:%02d:%02d\n",time[0],time[1],time[2]);  
    return 0;  
}  
