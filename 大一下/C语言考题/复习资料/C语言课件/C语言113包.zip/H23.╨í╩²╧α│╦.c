#include <stdio.h>  
#include <string.h>

int main()  
{  
	char str1[100],str2[100];
	int num1[100]={0},num2[100]={0},end[100]={0};
	int len1,len2,i,j,k=0,point1=0,point2=0,flag=0,flag3=0,flag4=0,flag2=0,fu1=0,fu2=0;
	int temp,yu,zheng;
	
	scanf("%s",&str1);
	getchar();
	scanf("%s",&str2);
	getchar();
	
	if(str1[0]=='-')
	{
		fu1=1;
		for(i=0;i<100;i++)
			str1[i]=str1[i+1];
	}
	
	if(str2[0]=='-')
	{
		fu2=-1;
		for(i=0;i<100;i++)
			str2[i]=str2[i+1];
	}
	
	len1=strlen(str1);
	len2=strlen(str2);
	
	for(i=len1-1,j=0;i>=0;i--)
	{
		if(str1[i]=='.')
		{
			point1=len1-1-i;
			continue;
		}
		num1[k++]=str1[i]-'0';
	}
	k=0;
	for(i=len2-1,j=0;i>=0;i--)
	{
		if(str2[i]=='.')
		{
			point2=len2-1-i;
			continue;
		}
		num2[k++]=str2[i]-'0';
	}
	
	for(i=0;i<len1;i++)
		for(j=0;j<len2;j++)
		{
			
			temp=num1[i]*num2[j];
			zheng=temp/10;
			yu=temp%10;
			end[i+j]+=yu;
			end[i+j+1]+=zheng;
		}
	
	for(i=0;i<len1+len2;i++)
	{
		end[i+1]+=end[i]/10;
		end[i]=end[i]%10;
	}
	
	for(i=point1+point2-1;i>=0;i--)
		if(end[i]!=0)
			flag2=1;
	
	for(i=0;i<len1;i++)
		if(num1[i]!=0)
			flag3=1;
			
	for(i=0;i<len2;i++)
		if(num2[i]!=0)
			flag4=1;
	
	if(fu1+fu2!=0&&flag3==1&&flag4==1)
		printf("-");
	
	for(j=0;end[j]==0&&j<point1+point2-1;j++)
	{}

	for(i=len1+len2;i>=j;i--)
	{
		if(end[i]==0&&flag==0&&i!=point1+point2)
			continue;
		if(i==point1+point2-1&&flag2==1)
			printf(".");
		if(i==point1+point2-1&&flag2==0)
			break;
		printf("%d",end[i]);
		flag=1;
	}
	printf("\n");
	
	return 0;
}  

