#include <stdio.h>
#include <math.h>
int main()
{
	double a2,b2,x0,y0,k;
	scanf("%lf %lf\n%lf %lf",&a2,&b2,&x0,&y0);
	k=b2/y0;
	if (x0*x0/a2+y0*y0/b2!=1)
		{
		 printf("Input error!\n");
		 goto k;
		}
	else
		if (y0==0)
			{
			 printf("x=%lf\n",x0);
			 goto k;
			}
		else if (x0==0)
			{
			 printf("y=%lf\n",y0);
			 goto k;
			}
			else 
				if (k>0)
					printf("y=%lfx+%lf\n",-b2*x0/a2/y0,k);
				else
					printf("y=%lfx%lf\n",-b2*x0/a2/y0,k);
	k:return 0;
}
