#include <stdio.h>
#include <math.h>
int main() 
{
 	int a,b,c,p;
	double x1,x2,d,q=1;
 	scanf("%d %d %d",&a,&b,&c);
 	if (a == 0 && b == 0)
 		{
		 printf("Input error!\n");
		 goto k;
		}
 	if (a == 0)		 
		x1= (-c / q) / (b / q);
 	else
 		{
 		 d = (b / q) * (b / q)- 4 * (a/q) * (c/q);
 		 p = 2 * (a / q);
		 x1 = (-b / q) / p;
 		 if (d>=0)
 		 	x2 = sqrt(d) / p;
	 	 else
 		 	x2 = sqrt(-d) / p;
		}
 
 	if (a == 0)
 		printf("x=%f\n",x1);
	else
 		if (d >= 0)
 			if (d == 0)
 			 printf("x1=x2=%f\n",x1);
 			else
			 printf("x1=%f\nx2=%f\n",x1+x2,x1-x2);
 		else 
 			if (x1 == 0)
 			 printf("x1=%fi\nx2=%fi\n",x1+x2,x1-x2);
			else 
			 printf("x1=%f+%fi\nx2=%f-%fi\n",x1,x2,x1,x2);
 	k:return 0;
}
