#include <stdio.h>  
#include <string.h>  
int main()  
{    
    int n,n1,i,j,k,flag;  
    unsigned long long a[10001];     
      
    scanf("%d",&n); 
	scanf("%d",&n1);  
    for(k=1;k<=n;k++)  
    {   
        flag=0;  
        for(i=0;i<n1;i++)  
            {  
            scanf("%llu",&a[i]);  
            if (flag==0)  
                for(j=0;j<i;j++)  
                    if(a[i]==a[j])  
                    {  
                        printf("%llu\n",a[i]);  
                        flag=1;  
                        break;  
                    }  
            }  
    }  
    return 0;  
}
