#include <stdio.h>  
int main()   
{  
    double n,a,b,c,ha,hb,hc,flag=0;  
    scanf("%lf",&n);  
    for (c=10*n;c>=2/5*10*n;c--)  
    for (b=(10*n-c)/0.5;b>=c/1.5*2;b--)  
        {  
            a=(10*n-c-0.5*b)*10;  
            ha=a*1.8;  
            hb=b*1.5;  
            hc=c*2;  
            (int) ha;  
            (int) hb;  
            (int) hc;  
            if (ha==hb&&hb==hc&&ha==hc)  
            {  
                printf("%.0f,%.0f,%.0f\n",a,b,c);  
                flag=1;  
            }  
        }  
    if (flag==0)  
        printf("No change.\n");  
    return 0;  
}  
