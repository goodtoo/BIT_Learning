#include <stdio.h>  
#include <string.h>  
int main()   
{  
    char x[1000];  
    int a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0;  
    int i;  
      
    gets(x);  
      
    for(i=0;i<strlen(x);i++)  
    {  
        if(x[i]=='a')  
            a1++;  
        if(x[i]=='e')  
            a2++;  
        if(x[i]=='i')  
            a3++;  
        if(x[i]=='o')  
            a4++;  
        if(x[i]=='u')  
            a5++;  
        if(x[i]=='A')  
            a6++;  
        if(x[i]=='E')  
            a7++;  
        if(x[i]=='I')  
            a8++;  
        if(x[i]=='O')  
            a9++;  
        if(x[i]=='U')  
            a10++;  
    }  
    for(i=0;i<a1;i++)  
        printf("a");  
    for(i=0;i<a2;i++)  
        printf("e");  
    for(i=0;i<a3;i++)  
        printf("i");  
    for(i=0;i<a4;i++)  
        printf("o");  
    for(i=0;i<a5;i++)  
        printf("u");  
    for(i=0;i<a6;i++)  
        printf("A");  
    for(i=0;i<a7;i++)  
        printf("E");  
    for(i=0;i<a8;i++)  
        printf("I");  
    for(i=0;i<a9;i++)  
        printf("O");  
    for(i=0;i<a10;i++)  
        printf("U");  
    printf("\n");  
    return 0;  
}  
