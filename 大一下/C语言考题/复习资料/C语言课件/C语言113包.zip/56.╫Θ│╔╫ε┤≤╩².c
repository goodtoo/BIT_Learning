#include<stdio.h>  
#include<string.h>  

int main()  
{    
    char a[10000];  
    int x[10]={0} ,i,j,len;  
     
	scanf("%s",a);  
    len=strlen(a);  
    for(i=0;i<len;i++) 
        x[a[i]-'0']++;  
	for(i=9;i>=0;i--)  
	    for( j=0;j<x[i];j++) 
            printf("%d",i);      
	printf("\n");
} 
