#include <stdio.h>
int main()
{char x;
scanf("%c",&x);
(x>64&&x<91||x>96&&x<123)
?
(x<91?printf("%c\n",x+32):printf("%c\n",x-32))
:
printf("%c\n",x);
return 0;
}
