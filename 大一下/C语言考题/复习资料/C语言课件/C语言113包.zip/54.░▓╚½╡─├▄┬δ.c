#include <stdio.h>
#include <math.h>
#include <string.h>

char a[100];

int crazy() 
{
	int b,c,d,len;
	int flag1=0,flag2=0,flag3=0,flag4=0,mark=0,i;
	len=strlen(a);
	if(len<6)
		return 1;

	for(i=0;i<len;i++)
	{
		if(a[i]>='0'&&a[i]<='9'&&flag1==0)
		{
			flag1=1;
			mark++;
		}
		else
		{
			if(a[i]>='A'&&a[i]<='Z'&&flag2==0)
			{
				flag2=1;
				mark++;
			}
			else
			{
				if(a[i]>='a'&&a[i]<='z'&&flag3==0)
				{
					flag3=1;
					mark++;
				}
				else
				{
					if((a[i]<'0'||(a[i]>'9'&&a[i]<'A')||(a[i]>'Z'&&a[i]<'a')||a[i]>'z'||a[i]==' ')&&flag4==0)
					{
						flag4=1;
						mark++;
					}
				}
			}
		}
	}
    switch (mark)
    {
    	case 1: return 1;
    	case 2: return 2;
    	case 3: return 3;
		case 4: return 3; 
	}	
}

int main()  
{  
	int n,i,j,temp;
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		gets(a);
		temp=crazy();
		switch(temp)
		{
			case 1: printf("Not Safe\n");break;
			case 2: printf("Medium Safe\n");break;
			case 3: printf("Safe\n");break;
		}
		for(j=0;j<100;j++)
	        a[j]=0;
	}
    return 0;  
}
