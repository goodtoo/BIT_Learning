#include <stdio.h>

char letter(char x,int y)
{
	int i;
	
	for(i=1;i<y;i++)
	{
		x++;
		if(x=='Z'+1)
			x='A';
	}
	return x; 
} 

int main()  
{  
	int n,n0;
	int i,j;
	char x,y;
	
	scanf("%c %d",&x,&n);
	for(i=1;i<=2*n-1;i++)
	{
		n0=i>n?2*n-i:i;
		y=letter(x,n0);
		for(j=1;j<=n-n0;j++)
			printf(" "); 
		printf("%c",y); 
		for(j=1;j<=2*n0-3;j++)
			printf(" ");
		if(n0!=1) 
			printf("%c",y);
		printf("\n");
	}
	return 0;
}  

