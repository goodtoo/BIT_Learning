#include <stdio.h>  
int main()   
{  
    int a[1000001],b[1000001],n,i,max=0,x;  
    scanf("%d",&n);  
    for(i=1;i<=n;i++)  
        scanf("%d",&a[i]);  
    for(i=1;i<=n;i++)  
        b[i]=1;  
    for(i=2;i<=n;i++)  
        if(a[i]<=a[i-1])  
            b[i]=b[i-1]+1;  
    for(i=1;i<=n;i++)  
    {  
        if(b[i]>max)  
        {  
            max=b[i];  
            x=i;  
        }  
    }  
    printf("%d %d\n",x-max+1,x);  
    return 0;  
}  
