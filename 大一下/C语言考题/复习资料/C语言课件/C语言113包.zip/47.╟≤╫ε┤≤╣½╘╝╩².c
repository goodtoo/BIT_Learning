int gongyue(int x,int y)  
{  
    int end,temp;  
      
    if(x<y)  
    {  
        temp=x;  
        x=y;  
        y=temp;  
    }                  
      
    if(x%y==0)  
        end=y;  
    else  
        end=gongyue(y,x%y);  
      
    return end;   
}  
  
int main()   
{  
    int n,m;  
      
    scanf("%d %d",&n,&m);  
    printf("%d\n",gongyue(n,m));  
      
    return 0;  
}  
