#include <stdio.h>   
#include <string.h>   
  
int main()  
{  
    char str[1000];  
    int i,i0,j,k=0,flag;  
    int len,sum=0;  
    int num[1000]={0};  
    char way[1000];  
      
    gets(str);  
  
    len=strlen(str);  
    for(i=0;i<len;i++)  
    {  
        if(str[i]=='+'||(str[i]=='-'&&(str[i+1]==' '||i==len-1))||str[i]=='*'||str[i]=='/')  
            {  
                way[k++]=str[i];  
                i+=1;  
            }  
        else if(str[i]!='-')  
            {     
                i0=i;  
                for(j=0;str[i]!=' ';i++)  
                    j++;  
                for(;j-1>=0;j--)  
                    num[k]=num[k]*10+(str[i0++]-'0');  
                k++;  
            }  
            else  
            {  
                i+=1;  
                i0=i;  
                for(j=0;str[i]!=' ';i++)  
                    j++;  
                for(;j-1>=0;j--)  
                    num[k]=num[k]*10+(str[i0++]-'0');  
                num[k]=-num[k];  
                k++;  
            }  
          
    }  
  
    way[k]='.';  
    for(i=0;way[i]!='.';i++)  
    {  
        flag=0;  
        if(way[i]=='+')  
            {  
                num[i-2]+=num[i-1];  
                flag=1;  
            }  
        if(way[i]=='-')  
            {  
                num[i-2]-=num[i-1];  
                flag=1;  
            }  
        if(way[i]=='*')  
            {  
                num[i-2]*=num[i-1];  
                flag=1;  
            }  
        if(way[i]=='/')  
            {  
                num[i-2]/=num[i-1];  
                flag=1;  
            }  
        if(flag==1)  
        {  
            for(j=i-1;j<997;j++)  
                num[j]=num[j+2];  
            for(j=i-1;j<997;j++)  
                way[j]=way[j+2];  
            i-=2;  
        }  
    }  
  
    printf("%d\n",num[0]);  
      
    return 0;  
}  
