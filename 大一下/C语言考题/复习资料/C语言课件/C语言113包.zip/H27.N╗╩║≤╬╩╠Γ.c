#include<stdio.h>  
#include<math.h>  
  
int y[9]={0};  
  
int place(int x)  
{  
    int i;  
    for(i=1;i<x;i++)  
        if(y[i]==y[x]||fabs(y[i]-y[x])==fabs(i-x))  
            return 0;  
    return 1;  
}  
  
int end(int n)  
{  
    int i,x=1,end=0;  
      
    y[x]=0;  
    while(x>0)  
    {  
        y[x]++;  
        while(y[x]<=n&&place(x)==0)  
            y[x]++;  
        if(y[x]<=n)  
        {  
            if(x==n)  
                end++;  
            else  
            {  
                x++;   
                y[x]=0;  
            }  
        }  
        else   
            x--;  
    }  
    return end;  
}  
  
int main()  
{  
    int n;  
      
    scanf("%d",&n);  
    printf("%d\n",end(n));  
    return 0;  
}  
