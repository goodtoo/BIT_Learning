#include <stdio.h>
int main ()
{
	int x,a,b;
	scanf("%d",&x);
	a=x/10;
	b=x%10;
	switch (b)
	{case 1:printf("Faint signals, barely perceptible, ");break;
	 case 2:printf("Very weak signals, ");break;
	 case 3:printf("Weak signals, ");break;
	 case 4:printf("Fair signals, ");break;
	 case 5:printf("Fairly good signals, ");break;
	 case 6:printf("Good signals, ");break;
	 case 7:printf("Moderately strong signals, ");break;
	 case 8:printf("Strong signals, ");break;
	 default :printf("Extremely strong signals, ");
	}
	switch (a)
	{case 1:printf("unreadable.\n");break;
	 case 2:printf("barely readable, occasional words distinguishable.\n");break;
	 case 3:printf("readable with considerable difficulty.\n");break;
	 case 4:printf("readable with practically no difficulty.\n");break;
	 default:printf("perfectly readable.\n");
	}
	return 0;
}
