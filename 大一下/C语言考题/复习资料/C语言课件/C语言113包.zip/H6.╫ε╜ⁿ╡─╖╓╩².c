#include <stdio.h>
#include <math.h>
int main ()
{
	double x,y,n,a,b,min=1,a1,b1,p,a2;
	scanf("%lf %lf %lf",&x,&y,&n);
	p = x / y;
	for(b = 1;b <= n ;b++)
		{
			a2=b * p;
		 	a2=(int)a2;
		 	a2=(double)a2;
			for(a = a2;a < a2 + 2;a++)
			{
				if (fabs(fabs (a / b-x / y) - min)>=0.000000000000001&&fabs (a / b-x / y) < min)
					{
						min = fabs (a / b-x / y);
						a1 = a;
						b1 = b;
					}
				else if (fabs(fabs (a / b-x / y) - min)<=0.000000000000001)
						{
							if (b < b1) 
								{
									b1 = b;
									a1 = a;
								}
							else if (b == b1)
									{
										if (a <= a1)
											{
												b1 = b;
												a1 = a;
											}
									}	
						}
			} 
		}
	printf("%ld/%ld\n",(long)a1,(long)b1);	
	return 0;
} 
