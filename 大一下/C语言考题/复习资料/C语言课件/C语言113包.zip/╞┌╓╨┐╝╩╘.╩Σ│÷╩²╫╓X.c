#include <stdio.h>

int main()
{
	int n,i,j,n0,y;
	int number(int x);
	
	scanf("%d",&n);
	getchar();
	
	if(n<1||n>9)
	{
		printf("input error\n");
		return 0;
	 } 
	for(i=1;i<=2*n-1;i++)
	{
		n0=i>n?2*n-i:i;
		y=number(i);
		
		for(j=1;j<=n0-1;j++)
			printf(" ");
		
		printf("%d",y);
		
		for(j=1;j<=2*n-2*n0-1;j++)
			printf(" ");
		
		if(i!=n)
			printf("%d",y);
		
		printf("\n");
	}
	return 0;
}

int number(int x)
{
	int i,y=1;
	
	for(i=1;i<x;i++)
	{
		y++;
		if(y==10)
			y=1;
	}
	return y;
}
