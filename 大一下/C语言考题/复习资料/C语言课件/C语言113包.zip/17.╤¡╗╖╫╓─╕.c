#include <stdio.h>  
int main()  
{  
    int k = 0;  
    char x;  
    x = getchar();  
    if (x <= 'Z')  
    {  
        while (x <= 'Z')  
        {  
            putchar (x++);  
            k = ++k;  
        }  
        x = x - 26;  
        while (k<26)  
        {  
            putchar (x++);  
            k = ++k;  
        }  
    }  
    else  
    {  
        while (x <= 'z')  
        {  
            putchar (x++);  
            k = ++k;  
        }  
        x = x - 26;  
        while (k<26)  
        {  
            putchar (x++);  
            k = ++k;  
        }  
    }  
    printf("\n");  
    return 0;  
}  
