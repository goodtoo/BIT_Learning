#include <stdio.h>  
#include <string.h>      
  
int main()    
{    
    int x,y,n,m,i,k,x1[502],y1[502],flag,p,q,end[503],longx,longy;     
    char a,temp[1005],x2[502],y2[502];  
      
    scanf("%d",&m);  
    getchar();  
    for(k=1;k<=m;k++)  
    {  
        for(i=0;i<=502;i++)  
        {  
            x1[i]=0;  
            y1[i]=0;  
            x2[i]=0;  
            y2[i]=0;  
            end[i]=0;  
        }  
        for(i=0;i<=1005;i++)  
            temp[i]='\0';  
        gets(temp);  
        flag=0;  
        p=0;  
        q=0;  
        for(i=0;i<strlen(temp);i++)  
        {  
            if(temp[i]=='+'||temp[i]=='-')  
            {  
                flag=1;  
                a=temp[i];  
                continue;  
            }  
            if(flag==0)  
            {  
                x2[p]=temp[i];  
                p+=1;  
            }  
            else  
            {  
                y2[q]=temp[i];  
                q+=1;  
            }  
        }  
        longx=p-1;  
        longy=q-1;  
        for(i=longx;i>=0;i--)  
            x1[i]=x2[longx-i]-'0';  
        for(i=longy;i>=0;i--)  
            y1[i]=y2[longy-i]-'0';  
        if(a=='+')  
        {     
            for(i=0; i<=(longx<longy?longy+1:longx+1); i++)  
            {  
                end[i] += x1[i]+y1[i];  
                if(end[i]>9)  
                {  
                    end[i] = end[i]-10;  
                    end[i+1]++;       
                }  
            }  
            if(end[(longx<longy?longy+1:longx+1)]==0)  
                for(i=(longx<longy?longy:longx);i>=0;i--)  
                    printf("%d",end[i]);  
            else  
                for(i=(longx<longy?longy+1:longx+1);i>=0;i--)  
                    printf("%d",end[i]);  
            printf("\n");  
        }  
        if(a=='-')  
        {  
            if(longx > longy)  
                n = 1;  
            else if(longx == longy)  
                n = strcmp(x2,y2);  
                else   
                    n = -1;  
            for(i=0; i<=(longx>longy?longx:longy); i++)  
            {  
                if(n>=0)  
                {  
                    if(x1[i]-y1[i] >= 0)  
                        end[i] = x1[i] - y1[i];  
                    else   
                    {  
                        end[i] = x1[i] + 10 - y1[i];  
                        x1[i+1]-=1;  
                    }  
                }  
                else   
                {  
                    if(y1[i]-x1[i] >= 0)  
                        end[i] = y1[i] - x1[i];  
                    else  
                    {  
                        end[i] = y1[i] + 10 - x1[i];  
                        y1[i+1]-=1;  
                    }  
                }  
            }  
            flag=0;  
            if(n<0)  
                printf("-");  
            for(i=(longx>longy?longx:longy);i>=0;i--)  
            {  
                if(end[i]==0&&flag==0&&i!=0)  
                    continue;  
                else   
                {  
                    printf("%d",end[i]);  
                    flag=1;  
                }  
            }  
            printf("\n");  
        }  
    }  
    return 0;  
}  
