#include<stdio.h>  
#include<string.h>  
  
int statmp(char w1[],char w2[])  
{  int l1,l2,i;  
   l1=strlen(w1);  
   l2=strlen(w2);  
   if(l1>=l2)  
     {    
        if(l1>l2)  
            return 1;  
        else  
        {    
            for(i=0;i<l1;i++)  
            {  
                if(w1[i]!=w2[i])  
                    return w1[i]-w2[i];  
            }  
            if(i==l1)   
                return 0;  
        }  
     }  
   else  
     return -1;  
}  
   
int main()  
{     
    int m,i,j,p,x,loc[10001]={0},flag;  
    char name[1001][100],num[10000],s[100];  
      
    scanf("%d",&m);                                              
    for(i=0;i<m;i++)  
    {     
        scanf("%s",name[i]);  
        scanf("%s",&num[loc[i]]);  
        loc[i+1]+=loc[i]+strlen(&num[loc[i]])+1;  
    }  
    for(i=0;i<m-1;i++)  
   {     
        p=i;  
        for(j=i+1;j<m;j++)  
        {   
            flag=statmp(&num[loc[p]],&num[loc[j]]);  
            if(flag<0)  
                p=j;  
            if(flag==0)  
            {     
                if(strcmp(name[p],name[j])>0)  
                    p=j;  
            }  
        }  
        if(p!=i)  
           {    
                x=loc[i];  
                strcpy(s,name[i]);  
                loc[i]=loc[p];  
                strcpy(name[i],name[p]);  
                loc[p]=x;  
                strcpy(name[p],s);  
           }  
   }  
    for(i=0;i<m;i++)  
        printf("%s\n",name[i]);  
}  
