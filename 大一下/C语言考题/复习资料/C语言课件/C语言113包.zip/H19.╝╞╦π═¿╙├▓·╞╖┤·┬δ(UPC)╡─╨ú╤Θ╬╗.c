#include <stdio.h>  
int main()  
{    
    int i,a,b1[5],c1[5],chang,sum1,sum2,x;  
    char b[5],c[5];  
      
    scanf("%d %s %s",&a,&b,&c);  
    for(i=0;i<=4;i++)  
    {  
        b1[i]=b[i]-'0';  
        c1[i]=c[i]-'0';  
    }  
    sum1=a+b1[1]+b1[3]+c1[0]+c1[2]+c1[4];  
    sum2=b1[0]+b1[2]+b1[4]+c1[1]+c1[3];  
    x=9-(3*sum1+sum2-1)%10;  
    printf("%d\n",x);  
    return 0;  
}  
