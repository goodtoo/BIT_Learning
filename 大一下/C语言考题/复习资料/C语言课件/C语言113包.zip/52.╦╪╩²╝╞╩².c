int *input(int n)    
{    
    int *p;    
    p=malloc(sizeof(int)*n);       
    if(p==NULL)    
        return NULL;   
    for(;n>0;n--)    
        scanf("%d",&p[n-1]);  
    return p;    
}    
  
int PrimCount(int *p,int n)    
{    
    int end=0;    
    for(;n>0;n--)       
        if(isPrim(p[n-1]))  
            end++;  
    free(p);     
    return end;    
}  

