#include <stdio.h> 
int main()
{
	int a[10][10],n,k,i = 1,j = 1,x = 1;
	scanf("%d",&n);
	for(k = 1;k <= 2 * n - 1;k++)
	{
		if(k%2 == 1)
		{
			for (;i >= 1&&j <= n;i--,j++)
				{
					a[i][j] = x++;
				}
			if (j == n + 1)
			{
				i += 2;
				j -= 1;
			}
			else if (i == 0)
					i += 1;
		}
		else
		{
			for(;i <= n && j >= 1;i++,j--)
				{
				a[i][j] = x++;
				}
			if(i == n + 1)
			{
				j += 2;
				i -= 1;
			}
			else if(j == 0)
					j += 1;
		}
	}
	for (i = 1;i <= n;i++)
	for (j = 1;j <= n;j++)
	{
		printf("%2d",a[i][j]);
		if (j != n)
			printf(" ");
		else
			printf("\n");
	}
	return 0;
}
