#include <stdio.h>  
#include <math.h>  
int main()  
{  
    int n, m;  
    int isPrime( int );  // ������������isPrim����1�����򷵻�0   
      
    scanf("%d%d", &n, &m);  
    while ( n < m-1 )  
    {  
        if ( isPrime(n) && isPrime(n+2) )  
        {  
            printf("%d,%d\n", n, n+2);  
        }  
        n++;  
    }  
    return 0;  
}  

int isPrime(int x)   
{   
    int i;  
    if(x%2==0)  
        return 0;  
    else  
        for(i=3;i<=x/2;i+=2)  
            if(x%i==0)  
                return 0;  
    return 1;  
}  
