#include <stdio.h>  
int main()   
{  
    char a[100],b[100];  
    int i,j,long1,flag,k;  
    scanf("%s",&a);  
    for(i=0;a[i]!='\0';i++)  
    {}  
    long1=i-1;  
    for(i=0;i<99;i++)  
        b[i]=0;  
    for(i=0,j=0;i<=long1;)  
    {  
        flag=0;  
        for(k=0;k<100;k++)  
            {  
                if(b[k]==a[i])  
                    flag=1;  
            }  
        if (flag==1)  
            i+=1;  
        else if(flag==0)  
        {  
            b[j]=a[i];  
            i+=1;  
            j+=1;  
        }  
    }  
    for(i=0;i<j;i++)  
        printf("%c",b[i]);  
    printf("\n");  
    return 0;  
}  
