#include<stdio.h>      
#define N 21  
int main()      
{      
    long a[N],b[N],n,k,x1,y1,x0=1,y0=1,i,j,yu=1,o;      
    scanf("%ld",&n);     
    for (k=1;k<=n;k++)     
        {    
            scanf("%ld %ld",&a[k],&b[k]);     
            if (a[k]==0)    
                {    
                    printf("0\n");    
                    return 0;    
                }    
        }    
    for (i=1;i<=n;i++)  
    {for (j=1;j<=n;j++)  
    {  
    x1=a[i];     
    y1=b[j];     
    if (x1<y1)     
        {     
            o=x1;     
            x1=y1;     
            y1=o;     
        }   
    while (yu!=0)    
        {     
            yu=x1%y1;  
            x1=y1;     
            y1=yu;     
        }
	yu=1;       
	a[i]/=x1;
	b[j]/=x1;
    }  }
    for(i=1;i<=n;i++)  
    {  
     x0*=a[i];  
     y0*=b[i];  
}  
                
    if (y0==1)     
        printf("%ld\n",x0);     
    else     
        printf("%ld/%ld\n",x0,y0);     
    return 0;     
} 
