#include <stdio.h>
int main() 
{ 
	double h,r,s,v,p=3.141592;
	scanf("%lf\n%lf",&r,&h);
	printf("s=%.2f,v=%.2f\n",2*p*r*h,p*r*r*h);
	return 0;
}
