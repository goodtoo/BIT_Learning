#include <stdio.h>  
int main()   
{  
    int n,a[20],b[20]={0},i,j=0,k;  
    scanf("%d",&n);  
    for(i=0;i<n;i++)  
        scanf("%d",&a[i]);  
    for(i=1;i<n;i++)  
    {  
        if(a[i-1]==a[i])  
            b[i]=b[i-1]+1;  
    }  
    for(i=1;i<n;i++)  
    {  
        if(b[i]>b[j])  
            j=i;  
    }  
    for(i=j;b[i]>0;i--)  
        k=i;  
    if(j==0)  
        printf("No equal number list.\n");  
    else  
        printf("The longest equal number list is from %d to %d.\n",k-1,j);  
    return 0;  
}  
