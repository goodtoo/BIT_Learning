#include <stdio.h>    
#include <math.h>    
int main()    
{    
    int a,b,i;    
    int isPrime( int ),huiwen( int );    
      
    scanf("%d %d", &a, &b);    
    for(i=a;i<=b;i++)  
    {  
        if(isPrime(i)==1)  
            if(huiwen(i)==1)  
                printf("%d\n",i);  
    }  
    return 0;  
}    
  
int isPrime(int x)   
{   
    int i;  
    if(x%2==0)  
        return 0;  
    else  
        for(i=3;i<=x/2;i+=2)  
            if(x%i==0)  
                return 0;  
    return 1;  
}  
  
int huiwen(int x)  
{  
    int y,sum=0;  
      
    y=x;  
    while(x)  
    {  
    sum=sum*10+x%10;  
    x=x/10;  
    }  
    if(y==sum)  
        return 1;  
    else   
        return 0;  
}
