#include<stdio.h> 
int main() 
{ 
    int x,y,a,b,yu,x0,y0;
    scanf("%d %d",&x,&y);
    x0=x;
    y0=y;
	if (x<y)
    	{
    		a=x;
    		x=y;
    		y=a;
		}
    for(yu=1;yu!=0;)
    	{
    		yu=x%y;
    		x=y;
    		y=yu;
		}
	printf("GCD(%d,%d)=%d\n",x0,y0,x); 
    return 0;
}

