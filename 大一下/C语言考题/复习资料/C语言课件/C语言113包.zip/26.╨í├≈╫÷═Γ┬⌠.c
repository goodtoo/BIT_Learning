#include <stdio.h>  
int main()   
{  
    int m,n,a,b,c,flag;  
    while (scanf("%d %d",&n,&m)!= EOF)  
    {  
        flag = 0;  
        for(a = n;a >= 0;a--)  
        for(b = n-a;b >= 0;b--)  
        {  
            c = n - a - b;  
            if (20 * a + 12 * b + 8 * c == m)  
            {  
                if (flag == 0)  
                {  
                    printf("KFC  McDonald  PissaHut\n");  
                    flag = 1;  
                }  
                printf("%d %d %d\n",a,b,c);  
            }  
        }  
    if (flag == 0)  
        printf("No Solution!\n");  
    }  
    return 0;  
}  
