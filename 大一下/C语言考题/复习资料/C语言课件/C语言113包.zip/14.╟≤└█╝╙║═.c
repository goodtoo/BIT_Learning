#include <stdio.h>
int main() 
{
	int n,m,t,x;
	scanf("%d%d",&n,&m);
	t=n;
	x=0;
	while(t<=m)
	{x=x+t;
	 t++;
	}
	printf("The sum from %d to %d is %d.\n",n,m,x);
	return 0;
}
