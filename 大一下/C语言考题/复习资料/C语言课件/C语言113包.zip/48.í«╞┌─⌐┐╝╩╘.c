#include <stdio.h>

int main()
{
	int k=1,flag=0;
	double i,j,n,m;
	
	scanf("%lf %lf",&n,&m);
	for(i=n;i>=0;i--)
		for(j=n-i;j>=0;j--)
			if((n-i-j)*2.5+j*5+i*10==m)
			{
				printf("%d:%0.f,%.0f,%.0f\n",k++,i,j,n-i-j);
				flag=1;
			}
	if(flag==0)
		printf("Error!\n");
	return 0;
}
