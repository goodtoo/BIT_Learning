#include <stdio.h>  
#include <string.h>  
char back(int Y)  
{  
    switch (Y)  
    {  
        case 0:return '1';break;  
        case 1:return '0';break;  
        case 2:return 'X';break;  
        case 3:return '9';break;  
        case 4:return '8';break;  
        case 5:return '7';break;  
        case 6:return '6';break;  
        case 7:return '5';break;  
        case 8:return '4';break;  
        case 9:return '3';break;  
        case 10:return '2';break;  
    }  
}  
int main()  
{  
    char a[20],temp;  
    int i,j,n,S,Y,b[20],chang;  
  
    scanf("%d",&n);  
    for(n;n>0;n--)  
    {  
        scanf("%s",&a);  
        chang=strlen(a);  
        for(i=0;i<chang;i++)  
            b[i]=a[i]-'0';  
        if(strlen(a)!=18&&strlen(a)!=15)  
        {  
            printf("Invalid\n");  
            continue;  
        }  
        if(strlen(a)==18)  
        {  
            S=7*b[0]+9*b[1]+10*b[2]+5*b[3]+8*b[4]+4*b[5]+2*b[6]+1*b[7]+6*b[8]+3*b[9]+7*b[10]+9*b[11]+10*b[12]+5*b[13]+8*b[14]+4*b[15]+2*b[16];  
            Y=S%11;  
            if(back(Y)==a[17])  
                printf("Valid\n");  
            else  
                printf("Invalid\n");  
        }  
        if(strlen(a)==15)  
        {  
            for(i=14;i>=6;i--)  
                b[i+2]=b[i];  
            if(b[14]==9&&b[15]==9&&(b[16]==9||b[16]==8||b[16]==7||b[16]==6))  
            {  
                b[6]=1;  
                b[7]=8;  
            }  
            else  
            {  
                b[6]=1;  
                b[7]=9;  
            }  
            S=7*b[0]+9*b[1]+10*b[2]+5*b[3]+8*b[4]+4*b[5]+2*b[6]+1*b[7]+6*b[8]+3*b[9]+7*b[10]+9*b[11]+10*b[12]+5*b[13]+8*b[14]+4*b[15]+2*b[16];  
            Y=S%11;  
            temp=back(Y);  
            for(i=0;i<=16;i++)  
                printf("%d",b[i]);  
            printf("%c\n",temp);  
        }  
    }  
    return 0;  
}  
