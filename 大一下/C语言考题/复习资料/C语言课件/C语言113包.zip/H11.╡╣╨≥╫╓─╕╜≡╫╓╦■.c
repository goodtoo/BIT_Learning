#include <stdio.h>
int main()
{ 	
	int a,h,i,j,p,q,n1=0,n2=0;
	char x,x1,x0;
	scanf("%c %d %d",&x,&a,&h);
	x1 = x;
	x0 = x;
	for(q = 1;q <= h;q++)
	{
		i = a;
		x = x1;
		for(j = h - q;j >= 1;j--)
			printf(" ");
		for(p = 1;p <=  (i + 1) / 2;p++)
		{
			printf("%c",x--);
			if (x+1 == 'Z')
				n1+=1;
			else if (x+1 == 'z')
					n2+=1;
			if (x == 'a' - 1)
 				x = 'z';
 			if (x == 'A' - 1)
				x = 'Z';
 		}
		if (x == 'z')
			x = 'a';
		else if (x == 'Z')
				x = 'A';
			else x += 1;
		if (a%2==0)
		{
			printf("%c",x);
			if (x == 'Z')
				n1+=1;
			else if (x == 'z')
					n2+=1;
			x += 1;
		}
		else
			x += 1;
		for(p = 1;p <= (i - 1) / 2;p++)
		{
			if (x == 'z' + 1)
 				x = 'a';
 			if (x == 'Z' + 1)
 				x = 'A';
			printf("%c",x++);
			if (x - 1 == 'Z')
				n1+=1;
			else if (x - 1 == 'z')
					n2+=1;
 		}
		printf("\n");
		a += 2;
	}
	if (x0>='A'&&x0<='Z')
		printf("������������ʹ��%d����ĸש��Z\n",n1);
		else
			printf("������������ʹ��%d����ĸש��z\n",n2);
	return 0;
}
