#include <stdio.h>  
int main()  
{     
    int h,i,j,k,i0,p,q;  
    char x,x1,x2;  
    scanf("%d %c",&h,&x);  
    if (x<'A'||x>'Z')  
    {  
        printf("input error.\n");  
        return 0;  
    }  
    x1=x;  
    if (x=='A')  
        x2='Z';  
    else  
        x2=x-1;  
    for (p=1;p<h;p++)  
        {  
            x1+=1;  
            if (x1>'Z')  
                x1='A';  
        }  
    for(i=1;i<=2*h-1;i++)  
    {  
        i0=i-h;  
        if (i0<0)  
        {  
            for(j=1;j<i;j++)  
                printf(" ");  
            for(k=j;k<=2*h-i;k++)  
            {  
                if (k==i||k==2*h-i)  
                    {  
                        if (k==2*h-i)  
                            x1+=1;  
                        if (x1>'Z')  
                            x1='A';  
                        printf("%c",x1--);  
                        if (x1<'A')  
                            x1='Z';  
                    }  
                else   
                    printf(" ");  
            }  
        printf("\n");  
        }  
        if (i0==0)  
        {  
            for(q=1;q<h;q++)  
                printf(" ");  
            printf("%c\n",x);  
        }  
        if (i0>0)  
        {  
            for(j=1;j<h-1-i0;j++)  
                printf(" ");  
            for(k=j;k<=h+i0;k++)  
            {  
                if (k==h-i0)  
                        printf("%c",x2);  
                else if (k==h+i0)  
                    {  
                        printf("%c",x2--);  
                        if (x2<'A')  
                        x2='Z';  
                    }  
                    else   
                        printf(" ");  
            }  
        printf("\n");  
        }  
    }  
    return 0;  
}  
