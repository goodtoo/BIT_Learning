#include<stdio.h>  
#include<string.h>  
int a[27][27];  
  
int func(int i, int j)  
{  
 int n;  
 n = a[i][j];  
 if (i - 1 >= 0)  
  n -= a[i - 1][j + 1];  
 return n;  
}  
  
int sub()  
{  
 int l, i = 0, sum = 0;  
 char ch[27];  
 gets(ch);  
 l = strlen(ch);  
 for (i = 0; i < l - 1; i++)  
 {  
  if (ch[i] >= ch[i + 1])  
   return 0;  
 }  
 i = 0;  
 for (i = 0; i < l; i++)  
  sum += func(l - i - 1, ch[i] - 'a');  
 return sum;  
}  
  
int main()  
{  
 int i, j, m = 26, n;  
 for (i = 0; i < m; i++)  
  a[0][i] = i + 1;  
 m--;  
 for (i = 1; i < 10; i++)  
 {  
  a[i][0] = a[i - 1][m] + 1;  
  for (j = 1; j < m; j++)  
   a[i][j] = a[i][j - 1] + a[i][0] - a[i - 1][j];  
  m--;  
 }  
 scanf("%d\n", &n);  
 while (n)  
 {  
  printf("%d\n",sub());  
  n--;  
 }  
 return 0;  
}  
