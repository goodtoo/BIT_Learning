#include <stdio.h> 

char facto(int x)
{
	int i;
	
	if(x%2==0&&x!=2)
		return 0;
	for(i=3;i<=(x+1)/2;i+=2)
		if(x%i==0)
			return 0;
	return 1;
}

int main()
{
	int score,sum=0,i,k=0,flag=0;
	char x;
	
	while(1)
	{
		scanf("%d",&score);
		if(score==0)
			break;
		if(score>80)
			flag=1;
		for(i=2;i<=score;i++)
			if(facto(i)==1)
				sum+=i;
		k++;
	}
	if(flag==0)
		printf("%d\n",sum*10/k);
	else
		printf("������!!!!!!\n");
	return 0;
}
