#include <stdio.h>  
   
int leap_year( int );     
int year_days( int );     
int days(int,int,int);    
  
int leap_year( int year )   
{   return ( (year%4==0 && year%100!=0) || year%400==0 ) ? 1 : 0;  
}  
  
int year_days(int year)  
{   return leap_year( year ) ? 366 : 365;  
}  
  
int days( int year, int month, int day ) 
{   int months[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31}, i;  
      
    if  ( leap_year( year ) && month >2 )  
        day++;  
      
    for ( i=1; i<month; i++ )  
        day += months[i];  
  
    return day;  
}  
int main()  
{  
    int d1,m1,y1,d2,m2,y2,sum1,sum2,sum3=0,i;  
      
    scanf("%d %d %d",&y1,&m1,&d1);  
    scanf("%d %d %d",&y2,&m2,&d2);  
    sum1=year_days(y1)-days(y1,m1,d1);  
    sum2=days(y2,m2,d2);  
    for(i=y1+1;i<y2;i++)  
        sum3+=year_days(i);  
    if(y1==y2)  
        printf("%d days\n",days(y2,m2,d2)-days(y1,m1,d1));  
    else  
        printf("%d days\n",sum1+sum2+sum3);  
    return 0;  
}  
