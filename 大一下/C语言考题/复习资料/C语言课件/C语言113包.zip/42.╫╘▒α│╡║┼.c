#include <stdio.h>      
int main()    
{    
    int a,b,i;    
    int daxie( char,char,char,char ),weihao( char );   
    char x[6];   
      
    scanf("%s", &x);    
    if(daxie(x[0],x[1],x[2],x[3])==1)  
        if(weihao(x[4])==1)  
            printf("ok.\n");  
        else  
            printf("no.\n");  
    else  
        printf("no.\n");  
    return 0;  
}    
  
int daxie(char a,char b,char c,char d)   
{   
    int flag=0;  
    if(a=='I'||a=='O'||b=='I'||b=='O'||c=='I'||c=='O'||d=='I'||d=='O')  
        return 0;  
    if('A'<=a&&a<='Z')  
        flag+=1;  
    if('A'<=b&&b<='Z')  
        flag+=1;  
    if('A'<=c&&c<='Z')  
        flag+=1;  
    if('A'<=d&&d<='Z')  
        flag+=1;  
    if(flag>=2)  
        return 1;  
    else  
        return 0;  
}  
  
int weihao (char x)  
{  
    if('0'<=x&&x<='9')  
        return 1;  
    return 0;  
      
}  

